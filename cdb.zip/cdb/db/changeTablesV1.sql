drop table cdb_CERT_OTHER_DOC;
drop table cdb_CERT_DOC;
drop table cdb_CERT_CONF_DECL_UPL_DOC;
drop table cdb_CERT_EUPDIRECTIVE_DOC;

create table cdb_CERT_OTHER_DOC
(
	primary key (CERTIFICATE_ID,CERT_OTHER_DOC_ID),
	foreign key (CERT_OTHER_DOC_ID) references cdb_document (id),
	foreign key (CERTIFICATE_ID) references CDB_CERTIFICATE (id),
	CERTIFICATE_ID number(19) not null,
	CERT_OTHER_DOC_ID number(19) not null
);

create table cdb_CERT_DOC
(
	primary key (CERTIFICATE_ID,CERT_DOC_ID),
	foreign key (CERT_DOC_ID) references cdb_document (id),
	foreign key (CERTIFICATE_ID) references CDB_CERTIFICATE (id),
	CERTIFICATE_ID number(19) not null,
	CERT_DOC_ID number(19) not null
);

create table cdb_CERT_CONF_DECL_UPL_DOC
(
	primary key (CERTIFICATE_ID,CERT_CONF_DECL_UPL_DOC_ID),
	foreign key (CERT_CONF_DECL_UPL_DOC_ID) references cdb_document (id),
	foreign key (CERTIFICATE_ID) references CDB_CERTIFICATE (id),
	CERTIFICATE_ID number(19) not null,
	CERT_CONF_DECL_UPL_DOC_ID number(19) not null
);

create table cdb_CERT_EUPDIRECTIVE_DOC
(
	primary key (CERTIFICATE_ID,CERT_EUPDIRECTIVE_DOC_ID),
	foreign key (CERT_EUPDIRECTIVE_DOC_ID) references cdb_document (id),
	foreign key (CERTIFICATE_ID) references CDB_CERTIFICATE (id),
	CERTIFICATE_ID number(19) not null,
	CERT_EUPDIRECTIVE_DOC_ID number(19) not null
);

INSERT INTO cdb_CERT_OTHER_DOC (CERTIFICATE_ID,CERT_OTHER_DOC_ID)
   SELECT id,CERT_OTHER_DOC_ID 
   FROM   cdb_certificate  where CERT_OTHER_DOC_ID is not null;

INSERT INTO cdb_CERT_DOC (CERTIFICATE_ID,CERT_DOC_ID)
   SELECT id,CERT_DOC_ID 
   FROM   cdb_certificate  where CERT_DOC_ID is not null;

INSERT INTO cdb_CERT_CONF_DECL_UPL_DOC (CERTIFICATE_ID,CERT_CONF_DECL_UPL_DOC_ID)
   SELECT id,CERT_CONF_DECL_UPL_DOC_ID 
   FROM   cdb_certificate  where CERT_CONF_DECL_UPL_DOC_ID is not null;

--new document in certificate   
--INSERT INTO cdb_CERT_EUPDIRECTIVE_DOC (CERTIFICATE_ID,CERT_EUPDIRECTIVE_DOC_ID)
--   SELECT id,CERT_EUPDIRECTIVE_DOC_ID 
--   FROM   cdb_certificate  where CERT_EUPDIRECTIVE_DOC_ID is not null
   
-- Drop columns 
alter table CDB_CERTIFICATE drop column cert_other_doc_id;
alter table CDB_CERTIFICATE drop column cert_doc_id;
alter table CDB_CERTIFICATE drop column cert_conf_decl_upl_doc_id;
alter table CDB_CERTIFICATE add cert_eupdirective_doc_remark VARCHAR2(4000 CHAR);


drop table CDB_INFORMATION_TYPE cascade constraints;
drop table CDB_INFORMATION cascade constraints;
drop table cdb_doc_information_document  cascade constraints;
drop table CDB_COUNTRY_INFORMATION  cascade constraints;

drop sequence cdb_s_information_type;
drop sequence cdb_s_information;
create sequence cdb_s_information start with 2000;
create sequence cdb_s_information_type start with 2000;

create table CDB_INFORMATION_TYPE
(
	primary key (ID),
  ID   NUMBER(19) not null,
  NAME VARCHAR2(255 CHAR),
  REMARK  VARCHAR2(4000 CHAR)
);

create table CDB_INFORMATION
(
	primary key (ID),
	foreign key (COUNTRY_ID) references CDB_COUNTRY (ID),
	foreign key (INFORMATION_TYPE_ID) references CDB_INFORMATION_TYPE (ID),
	foreign key (CREATE_USER_ID) references cdb_user (ID),
	foreign key (update_USER_ID) references cdb_user (ID),
  ID                	NUMBER(19) not null,
  CREATE_DATE        	TIMESTAMP(6),
  UPDATE_DATE           TIMESTAMP(6),
  CREATE_USER_ID		NUMBER(19),
  UPDATE_USER_ID		NUMBER(19),
  NAME                  VARCHAR2(255 CHAR),
  CODE                  VARCHAR2(255 CHAR),
  ABBREVIATION          VARCHAR2(255 CHAR),
  INFORMATION_TYPE_ID    NUMBER(19),
  COUNTRY_ID            NUMBER(19),
  REMARK                VARCHAR2(4000 CHAR)
);

create table cdb_doc_information_document
(
	primary key (information_id,document_id),
	foreign key (document_id) references cdb_document (id),
	foreign key (information_id) references cdb_information (id),
	information_id number(19) not null,
	document_id number(19) not null
);
create table CDB_COUNTRY_INFORMATION
(
	foreign key (INFORMATION_ID) references CDB_INFORMATION (ID),
	foreign key (COUNTRY_ID) references CDB_country (ID),
  COUNTRY_ID    NUMBER(19) not null,
  INFORMATION_ID NUMBER(19) not null
);