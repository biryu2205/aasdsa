drop sequence cdb_s_user;
drop sequence cdb_s_country;
drop sequence cdb_s_product_category;
drop sequence cdb_s_product_group;
drop sequence cdb_s_brand;
drop sequence cdb_s_regulation_type;
drop sequence cdb_s_regulation;
drop sequence cdb_s_certificate;
drop sequence cdb_s_institute;
drop sequence cdb_s_product;
drop sequence cdb_s_document;
drop sequence cdb_s_reg_req;

create sequence cdb_s_brand start with 2020;
create sequence cdb_s_certificate start with 6920;
create sequence cdb_s_country start with 2060;
create sequence cdb_s_document start with 8740;
create sequence cdb_s_institute start with 2880;
create sequence cdb_s_product start with 5410;
create sequence cdb_s_product_category start with 2000;
create sequence cdb_s_product_group start with 2200;
create sequence cdb_s_reg_req start with 2300;
create sequence cdb_s_regulation start with 3330;
create sequence cdb_s_regulation_type start with 2050;
create sequence cdb_s_user start with 2260;

update cdb_user set user_name ='wlm1fe', last_name ='WALTHER', first_name ='MARKUS' where id = 1;