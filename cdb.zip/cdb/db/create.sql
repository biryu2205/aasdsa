drop table cdb_user CASCADE CONSTRAINTS;
drop table cdb_role CASCADE CONSTRAINTS;
drop table cdb_USER_ROLE cascade constraints;
drop table cdb_continent cascade constraints;
drop table cdb_country cascade constraints;
drop table CDB_PRODUCT_CATEGORY cascade constraints;
drop table CDB_PRODUCT_group cascade constraints;
drop table CDB_BRAND cascade constraints;
drop table CDB_REGULATION_TYPE cascade constraints;
drop table CDB_REGULATION cascade constraints;
drop table CDB_certificate cascade constraints;
drop table CDB_institute cascade constraints;
drop table CDB_product cascade constraints;
drop table CDB_document cascade constraints;
drop table CDB_reg_req cascade constraints;
drop table CDB_brand_product cascade constraints;
drop table CDB_COUNTRY_REGULATION cascade constraints;
drop table CDB_REGULATION_CERTIFICATE cascade constraints;
drop table CDB_COUNTRY_INSTITUTE cascade constraints;
drop table CDB_REGULATION_INSTITUTE cascade constraints;
drop table CDB_NOVELTY cascade constraints;
drop table cdb_regreq_prodgroup cascade constraints;
drop table cdb_cert_expwarnrecip cascade constraints;
drop table cdb_doc_regulation_document cascade constraints;
drop table cdb_doc_regreq_document cascade constraints;


drop sequence cdb_s_user;
drop sequence cdb_s_country;
drop sequence cdb_s_product_category;
drop sequence cdb_s_product_group;
drop sequence cdb_s_brand;
drop sequence cdb_s_regulation_type;
drop sequence cdb_s_regulation;
drop sequence cdb_s_certificate;
drop sequence cdb_s_institute;
drop sequence cdb_s_product;
drop sequence cdb_s_document;
drop sequence cdb_s_reg_req;

create sequence cdb_s_brand start with 2000;
create sequence cdb_s_certificate start with 2000;
create sequence cdb_s_country start with 2000;
create sequence cdb_s_document start with 2000;
create sequence cdb_s_institute start with 2000;
create sequence cdb_s_product start with 2000;
create sequence cdb_s_product_category start with 2000;
create sequence cdb_s_product_group start with 2000;
create sequence cdb_s_reg_req start with 2000;
create sequence cdb_s_regulation start with 2000;
create sequence cdb_s_regulation_type start with 2000;
create sequence cdb_s_user start with 2000;

create table CDB_USER
(
	primary key (ID),
  ID         NUMBER(19) not null,
  USER_NAME  VARCHAR2(255 CHAR),
  LAST_NAME  VARCHAR2(255 CHAR),
  FIRST_NAME VARCHAR2(255 CHAR),
  DEPARTMENT VARCHAR2(255 CHAR),
  ACTIVE     NUMBER(1)
);

create table cdb_ROLE
(
	primary key (ID),
  ID   NUMBER(19) not null,
  NAME VARCHAR2(255)
);

create table CDB_NOVELTY
(
 primary key (ID),
  ID      NUMBER(19) not null,
  CONTENT VARCHAR2(4000 CHAR)
);

create table CDB_BRAND
(
	primary key (ID),
  ID   NUMBER(19) not null,
  NAME VARCHAR2(255 CHAR),
  REMARK            VARCHAR2(4000 CHAR)
);

create table CDB_REGULATION_TYPE
(
	primary key (ID),
  ID   NUMBER(19) not null,
  NAME VARCHAR2(255 CHAR),
  REMARK  VARCHAR2(4000 CHAR)
);

create table CDB_PRODUCT_CATEGORY
(
	primary key (ID),
  ID   NUMBER(19) not null,
  NAME VARCHAR2(255 CHAR),
  REMARK  VARCHAR2(4000 CHAR)
);

create table CDB_DOCUMENT
(
	primary key (ID),
	ID           NUMBER(19) not null,
  folder varchar2(255 char),
  FILE_NAME    VARCHAR2(255 CHAR),
  CONTENT_TYPE VARCHAR2(255 CHAR),
  FILE_SIZE    NUMBER(10)
);

create table CDB_CONTINENT
(
	primary key (ID),
	ID   NUMBER(19) not null,
  NAME VARCHAR2(255 CHAR)
);

create table CDB_COUNTRY
(
	primary key (ID),
	foreign key (CONTINENT_ID) references CDB_CONTINENT (ID),
  ID           NUMBER(19) not null,
  NAME         VARCHAR2(255 CHAR),
  CONTINENT_ID NUMBER(19),
  CODE         VARCHAR2(255 CHAR)
);

create table CDB_INSTITUTE
(
	primary key (ID),
	foreign key (CREATE_USER_ID) references cdb_user (ID),
	foreign key (update_USER_ID) references cdb_user (ID),
  ID      			NUMBER(19) not null,
  CREATE_DATE   	TIMESTAMP(6),
  UPDATE_DATE   	TIMESTAMP(6),
  CREATE_USER_ID	NUMBER(19),
  UPDATE_USER_ID	NUMBER(19),
  NAME    			VARCHAR2(255 CHAR),
  CONTACT_PERSON 	VARCHAR2(4000 CHAR),
  CONTACT 			VARCHAR2(4000 CHAR),
  REMARK  			VARCHAR2(4000 CHAR)
);

create table CDB_PRODUCT_group
(
	primary key (ID),
	foreign key (PRODUCT_CATEGORY_ID) references CDB_PRODUCT_CATEGORY (ID),
	foreign key (TYPE_PLATE_DOC_ID) references CDB_DOCUMENT (ID),
  ID                  NUMBER(19) not null,
  NAME                VARCHAR2(255 CHAR),
  PRODUCT_CATEGORY_ID NUMBER(19),
  REMARK              VARCHAR2(4000 CHAR),
  TYPEPLATE           VARCHAR2(2000 CHAR),
  TYPE_PLATE_DOC_ID   NUMBER(19)
);

create table CDB_REGULATION
(
	primary key (ID),
	foreign key (COUNTRY_ID) references CDB_COUNTRY (ID),
	foreign key (REGULATION_TYPE_ID) references CDB_REGULATION_TYPE (ID),
	foreign key (CREATE_USER_ID) references cdb_user (ID),
	foreign key (update_USER_ID) references cdb_user (ID),
  ID                	NUMBER(19) not null,
  CREATE_DATE        	TIMESTAMP(6),
  UPDATE_DATE           TIMESTAMP(6),
  CREATE_USER_ID		NUMBER(19),
  UPDATE_USER_ID		NUMBER(19),
  NAME                  VARCHAR2(255 CHAR),
  CODE                  VARCHAR2(255 CHAR),
  ABBREVIATION          VARCHAR2(255 CHAR),
  REGULATION_TYPE_ID    NUMBER(19),
  COUNTRY_ID            NUMBER(19),
  REMARK                VARCHAR2(4000 CHAR)
);

create table CDB_PRODUCT
(
	primary key (ID),
	foreign key (BRAND_ID) references CDB_BRAND (ID),
	foreign key (PRODUCT_group_ID) references CDB_PRODUCT_group (ID),
	foreign key (CREATE_USER_ID) references cdb_user (ID),
	foreign key (update_USER_ID) references cdb_user (ID),
  ID                NUMBER(19) not null,
  CREATE_DATE       TIMESTAMP(6),
  UPDATE_DATE       TIMESTAMP(6),
  CREATE_USER_ID	NUMBER(19),
  UPDATE_USER_ID	NUMBER(19),
  NAME              VARCHAR2(255 CHAR),
  BRAND_ID          NUMBER(19),
  REMARK            VARCHAR2(4000 CHAR),
  PRODUCT_group_ID NUMBER(19)
);

create table CDB_CERTIFICATE
(
	primary key (ID),
	foreign key (CERT_DOC_ID) references CDB_DOCUMENT (ID),
	foreign key (PRODUCT_ID) references CDB_PRODUCT (ID),
	foreign key (INSTITUTE_ID) references CDB_INSTITUTE (ID),
	foreign key (CERT_OTHER_DOC_ID) references CDB_DOCUMENT (ID),
	foreign key (CREATE_USER_ID) references cdb_user (ID),
	foreign key (update_USER_ID) references cdb_user (ID),
  ID                    NUMBER(19) not null,
  CERTIFICATE_NUMBER    VARCHAR2(30 CHAR),
  REMARK                VARCHAR2(4000 CHAR),
  CREATE_DATE           TIMESTAMP(6),
  UPDATE_DATE           TIMESTAMP(6),
  CREATE_USER_ID		NUMBER(19),
  UPDATE_USER_ID		NUMBER(19),
  VALID_UNTIL           TIMESTAMP(6),
  expiry_warning        TIMESTAMP(6),
  CERT_DOC_REMARK       VARCHAR2(4000 CHAR),
  CERT_OTHER_DOC_REMARK VARCHAR2(4000 CHAR),
  CONF_DECL_DOC_REMARK  VARCHAR2(4000 CHAR),
  PRODUCT_ID            NUMBER(19) not null,
  CERT_OTHER_DOC_ID     NUMBER(19),
  CERT_DOC_ID           NUMBER(19),
  INSTITUTE_ID          NUMBER(19) not null,
  CONF_DECL_DOC      	VARCHAR2(4000 CHAR),
  cert_conf_decl_upl_doc_id number(19)
);

create table CDB_REG_REQ
(
	primary key (ID),
	foreign key (REGULATION_ID) references CDB_REGULATION (ID),
	foreign key (CREATE_USER_ID) references cdb_user (ID),
	foreign key (update_USER_ID) references cdb_user (ID),
  ID                NUMBER(19) not null,
  CREATE_DATE       TIMESTAMP(6),
  UPDATE_DATE       TIMESTAMP(6),
  CREATE_USER_ID	NUMBER(19),
  UPDATE_USER_ID	NUMBER(19),
  MANDATORY         NUMBER(1),
  REMARK            VARCHAR2(2000 CHAR),
  REGULATION_ID     NUMBER(19) not null
);

create table cdb_USER_ROLE
(
	foreign key (USER_ID) references cdb_USER (ID),
	foreign key (ROLE_ID) references cdb_ROLE (ID),
  USER_ID NUMBER(19) not null,
  ROLE_ID NUMBER(19) not null
);

create table CDB_BRAND_PRODUCT
(
	foreign key (BRAND_ID) references CDB_Brand (ID),
	foreign key (PRODUCT_ID) references CDB_product (ID),
  BRAND_ID   NUMBER(19) not null,
  PRODUCT_ID NUMBER(19) not null
);

create table CDB_COUNTRY_REGULATION
(
	foreign key (REGULATION_ID) references CDB_regulation (ID),
	foreign key (COUNTRY_ID) references CDB_country (ID),
  COUNTRY_ID    NUMBER(19) not null,
  REGULATION_ID NUMBER(19) not null
);

create table CDB_REGULATION_CERTIFICATE
(
	foreign key (CERTIFICATE_ID) references CDB_CERTIFICATE (ID),
	foreign key (REGULATION_ID) references CDB_REGULATION (ID),
  CERTIFICATE_ID NUMBER(19) not null,
  REGULATION_ID  NUMBER(19) not null
);

create table CDB_COUNTRY_INSTITUTE
(
	foreign key (INSTITUTE_ID) references CDB_INSTITUTE (ID),
	foreign key (COUNTRY_ID) references CDB_COUNTRY (ID),
  INSTITUTE_ID NUMBER(19) not null,
  COUNTRY_ID   NUMBER(19) not null
);

create table cdb_regreq_prodgroup
(
	foreign key (regreq_id) references CDB_reg_req (ID),
	foreign key (prodgroup_id) references CDB_PRODUCT_group (ID),
  regreq_id NUMBER(19) not null,
  prodgroup_id  NUMBER(19) not null
);

create table CDB_REGULATION_INSTITUTE
(
	foreign key (INSTITUTE_ID) references CDB_INSTITUTE (ID),
	foreign key (REGULATION_ID) references CDB_REGULATION (ID),
  INSTITUTE_ID  NUMBER(19) not null,
  REGULATION_ID NUMBER(19) not null
);

create table cdb_cert_expwarnrecip
(
	foreign key (certificate_id) references CDB_certificate (ID),
	foreign key (user_id) references CDB_USER (ID),
  certificate_id  NUMBER(19) not null,
  user_id NUMBER(19) not null
);

create table cdb_doc_regulation_document
(
	primary key (regulation_id,document_id),
	foreign key (document_id) references cdb_document (id),
	foreign key (regulation_id) references cdb_regulation (id),
	regulation_id number(19) not null,
	document_id number(19) not null
);

create table cdb_doc_regreq_document
(
	primary key (regreq_id,document_id),
	foreign key (document_id) references cdb_document (id),
	foreign key (regreq_id) references CDB_reg_req (id),
	regreq_id number(19) not null,
	document_id number(19) not null
);


