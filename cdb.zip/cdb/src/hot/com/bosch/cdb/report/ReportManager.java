package com.bosch.cdb.report;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporter;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRXlsExporter;
import net.sf.jasperreports.engine.util.JRLoader;

import org.jboss.seam.annotations.Create;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;

@Name("reportManager")
public class ReportManager
{
    public static String CONTENT_TYPE_EXCEL = "application/vnd.ms-excel";
    public static String CONTENT_TYPE_PDF = "application/pdf";

	@In FacesContext facesContext;
	private DataSource datasource;

    @Create
    public void init() throws NamingException
    {
        // get DB data source using JNDI
        InitialContext ctx = new InitialContext();
        datasource = (DataSource) ctx.lookup("java:/cdbDatasource");
    }

	private void reportPdf(String reportPath, Map<String,Object> parameters) throws IOException, JRException, SQLException
	{
        String filename = "report.pdf";
        HttpServletResponse response = (HttpServletResponse) facesContext.getExternalContext().getResponse();
        response.setHeader("Content-disposition", "attachment; filename=" + filename);
        response.setContentType(CONTENT_TYPE_PDF);
        ServletOutputStream outputStream = response.getOutputStream();

        // load report
        InputStream inputStream = facesContext.getExternalContext().getResourceAsStream(reportPath);
        JasperReport report = (JasperReport) JRLoader.loadObject(inputStream);

        // fill report with data
        Connection connection = datasource.getConnection();
        JasperPrint jasperPrint = JasperFillManager.fillReport(report, parameters, connection);

        // export report in pdf format to response
        JRExporter exporter = new JRPdfExporter();
        exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
        exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, outputStream);
        exporter.exportReport();

        // close servlet output stream
        outputStream.close();

        // close DB connection
        connection.close();
        
        facesContext.responseComplete();

	}
	
	private void reportExcel(String reportPath, Map<String,Object> parameters) throws IOException, JRException, SQLException
	{
	        //Setup the output
	        String filename = "report.xls";
	        HttpServletResponse response = (HttpServletResponse) facesContext.getExternalContext().getResponse();
	        response.setHeader("Content-disposition", "attachment; filename=" + filename);
	        response.setContentType(CONTENT_TYPE_EXCEL);
	        ServletOutputStream outputStream = response.getOutputStream();
	        
	        // load report
	        InputStream inputStream = facesContext.getExternalContext().getResourceAsStream(reportPath);
	        JasperReport report = (JasperReport) JRLoader.loadObject(inputStream);

	        // fill report with data
	        Connection connection = datasource.getConnection();
	        JasperPrint jasperPrint = JasperFillManager.fillReport(report, parameters, connection);

	        // export report in excel format to response
	        JRExporter exporter = new JRXlsExporter();
	        exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
	        exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, outputStream);
	        exporter.exportReport();
	        
	        // close servlet output stream
	        outputStream.close();

	        // close DB connection
	        connection.close();
	        
	        facesContext.responseComplete();

	}
	
	public void reportRegulationExcel() throws IOException, JRException, SQLException
	{
        // specify report parameters
        Map<String,Object> parameters = new HashMap<String,Object>();
        parameters.put("IS_IGNORE_PAGINATION", Boolean.TRUE);
        parameters.put("MY_PARAM", "Some Value");

        reportExcel("/WEB-INF/report/regulation.jasper", parameters);
	}
	
	public void reportRegulationPdf() throws IOException, JRException, SQLException
	{
        // specify report parameters
        Map<String,Object> parameters = new HashMap<String,Object>();
        parameters.put("IS_IGNORE_PAGINATION", Boolean.FALSE);
        parameters.put("MY_PARAM", "Some Value");

        reportPdf("/WEB-INF/report/regulation.jasper", parameters);
	}

}
