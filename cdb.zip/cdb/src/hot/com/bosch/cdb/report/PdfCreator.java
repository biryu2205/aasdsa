package com.bosch.cdb.report;

import java.io.IOException;
import java.net.MalformedURLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;

import javax.faces.context.FacesContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;

import com.bosch.cdb.entity.Brand;
import com.bosch.cdb.entity.Certificate;
import com.bosch.cdb.entity.Information;
import com.bosch.cdb.entity.Institute;
import com.bosch.cdb.entity.Product;
import com.bosch.cdb.entity.ProductCategory;
import com.bosch.cdb.entity.Regulation;
import com.bosch.cdb.entity.RegulationRequirement;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.List;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

@Name("pdfCreator")
public class PdfCreator 
{
	com.lowagie.text.Document document;
	ServletOutputStream out;	
	FacesContext context;
	
	@In(value="#{facesContext}")
	FacesContext facesContext;

	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	
	Font fontLarge = FontFactory.getFont(FontFactory.TIMES, 12, Font.BOLD);
    Font fontSmall = FontFactory.getFont(FontFactory.TIMES, 6, Font.BOLD);
    Font fontLabel = FontFactory.getFont(FontFactory.TIMES, 10, Font.BOLD);
    Font fontValue = FontFactory.getFont(FontFactory.TIMES, 10, Font.NORMAL);
    Font fontHeadline = FontFactory.getFont(FontFactory.TIMES, 14, Font.BOLD);
    Font fontListItem = FontFactory.getFont(FontFactory.TIMES, 9, Font.NORMAL);
    
    Image image;
    PdfPTable table;
    PdfPCell cell;
    Paragraph paragraph;
    List list;
    
	private void addHeader(com.lowagie.text.Document document) throws DocumentException, MalformedURLException, IOException
	{
        table = new PdfPTable(2);
        table.setWidthPercentage(100);
        
        
        cell = new PdfPCell();
        paragraph = new Paragraph("TT-Certification Database", fontLarge);
        paragraph.setAlignment(Element.ALIGN_CENTER);
        cell.addElement(paragraph);
        table.addCell(cell);

        cell = new PdfPCell();
        Image image = Image.getInstance(facesContext.getExternalContext().getResource("/img/bosch_logo.jpg"));
        image.setAlignment(Element.ALIGN_CENTER);
        image.scalePercent(5);
        cell.addElement(image);
        table.addCell(cell);

        document.add(table);
        


	}
	
	private void initDocument(String name) throws IOException, DocumentException
	{
        // Setup the output
        context = FacesContext.getCurrentInstance();
        final HttpServletResponse response = (HttpServletResponse) context.getExternalContext().getResponse();
        response.setHeader("Content-disposition", "attachment; filename=" + name + ".pdf");
        response.setContentType("application/pdf");
        out = response.getOutputStream();

        // write pdf document to output stream
        document = new com.lowagie.text.Document();
        PdfWriter.getInstance(document, out);
        document.open();
        
        addHeader(document);
        
        paragraph = new Paragraph(name, fontHeadline);
        paragraph.setAlignment(Element.ALIGN_LEFT);
        paragraph.setSpacingBefore(15f);
        paragraph.setSpacingAfter(15f);
        
        document.add(paragraph);

        
        float[] colSizes = { 1f, 3f };

        table = new PdfPTable(colSizes);
        table.setWidthPercentage(100);
		
	}
	
	private void sendResponse() throws IOException, DocumentException
	{
		addLabelValue("", "");
		addLabelValue("Print Date", new Date());
        document.add(table);

        document.close();
        
        out.close();
        context.responseComplete();
	}
	
	public void print(Regulation regulation) throws IOException, DocumentException
	{
		initDocument("Regulation");
        
        addLabelValue("Creation Date", regulation.getCreateDate());
        addLabelValue("Last Update", regulation.getUpdateDate());
        addLabelValue("Creator", regulation.getCreateUser());
        addLabelValue("Last Updater", regulation.getUpdateUser());
        addLabelValue("Name", regulation.getName());
        addLabelValue("Regulation Type", regulation.getRegulationType().getName());
        addLabelValue("Abbreviation", regulation.getAbbreviation());
        addLabelValue("Code", regulation.getCode());
        addLabelValue("Remark", regulation.getRemark());
        addLabelValue("Countries", regulation.getCountryListString() );

        sendResponse();
	}
	
	public void print(Information information) throws IOException, DocumentException
	{
		initDocument("Information");
        
        addLabelValue("Creation Date", information.getCreateDate());
        addLabelValue("Last Update", information.getUpdateDate());
        addLabelValue("Creator", information.getCreateUser());
        addLabelValue("Last Updater", information.getUpdateUser());
        addLabelValue("Name", information.getName());
        addLabelValue("Information Type", information.getInformationType().getName());
        addLabelValue("Abbreviation", information.getAbbreviation());
        addLabelValue("Code", information.getCode());
        addLabelValue("Remark", information.getRemark());
        addLabelValue("Countries", information.getCountryListString() );

        sendResponse();
	}

	public void print(RegulationRequirement x) throws IOException, DocumentException
	{
		initDocument("Regulation Requirement");
        
        addLabelValue("Creation Date", x.getCreateDate());
        addLabelValue("Last Update", x.getUpdateDate());
        addLabelValue("Creator", x.getCreateUser());
        addLabelValue("Last Updater", x.getUpdateUser());
        addLabelValue("Product Category", x.getProductCategoryListString()); 
        addLabelValue("Regulation", x.getRegulation().getName());
        addLabelValue("Regulation Type", x.getRegulation().getRegulationType().getName());
        addLabelValue("Regulation Countries", x.getRegulation().getCountryListString());
        addLabelValue("Mandatory", x.getMandatory());
        addLabelValue("Remark", x.getRemark());

        sendResponse();
	}

	public void print(Product x) throws IOException, DocumentException
	{
		initDocument("Product");
        
        addLabelValue("Creation Date", x.getCreateDate());
        addLabelValue("Last Update", x.getUpdateDate());
        addLabelValue("Creator", x.getCreateUser());
        addLabelValue("Last Updater", x.getUpdateUser());
        addLabelValue("Name", x.getName());
        addLabelValue("Product Category", x.getProductCategory().getName());
        addLabelValue("Remark", x.getRemark());
        addLabelValue("Brands", x.getBrandList());

        sendResponse();
	}

	public void print(Certificate x) throws IOException, DocumentException
	{
		initDocument("Certificate");
        
        addLabelValue("Creation Date", x.getCreateDate());
        addLabelValue("Last Update", x.getUpdateDate());
        addLabelValue("Creator", x.getCreateUser());
        addLabelValue("Last Updater", x.getUpdateUser());
        addLabelValue("Certificate Number", x.getCertificateNumber());
        addLabelValue("Product", x.getProduct().getName());
        addLabelValue("Regulations", x.getRegulationList());
        addLabelValue("Institute", x.getInstitute().getName());
        addLabelValue("Remark", x.getRemark());
        addLabelValue("Valid Until", x.getValidUntil());
        addLabelValue("Expiry Warning", x.getExpiryWarning());
        addLabelValue("Certificate Document Remark", x.getCertDocRemark());
        addLabelValue("Other Document Remark", x.getCertOtherDocRemark());
        addLabelValue("Declaration of Conf. URL", x.getConfDeclDoc());
        addLabelValue("Declaration of Conf. Remark", x.getConfDeclDocRemark());

        sendResponse();
	}

	public void print(Institute x) throws IOException, DocumentException
	{
		initDocument("Institute");
        
        addLabelValue("Creation Date", x.getCreateDate());
        addLabelValue("Last Update", x.getUpdateDate());
        addLabelValue("Creator", x.getCreateUser());
        addLabelValue("Last Updater", x.getUpdateUser());
        addLabelValue("Name", x.getName());
        addLabelValue("Countries", x.getCountryListString());
        addLabelValue("Regulations", x.getRegulationList());
        addLabelValue("Contact Person", x.getContactPerson());
        addLabelValue("Contact", x.getContact());
        addLabelValue("Remark", x.getRemark());

        sendResponse();
	}

	
	private void addLabelValue(String label, Object value)
	{
        cell = new PdfPCell();
        paragraph = new Paragraph(label, fontLabel);
        paragraph.setAlignment(Element.ALIGN_RIGHT);
        cell.addElement(paragraph);
        table.addCell(cell);

        cell = new PdfPCell();
        paragraph = new Paragraph(getPrintString(value), fontValue);
        paragraph.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(paragraph);
        table.addCell(cell);		
	}
	
	private String getPrintString(Object object)
	{
		if (null == object)
		{
			return "";
		}
		else
		{
			if (object instanceof Date)
			{
				return dateFormat.format(object);
			}
			if (object instanceof Boolean)
			{
				Boolean b = (Boolean) object;
				if (b)
				{
					return "Yes";
				}
				else
				{
					return "No";
				}
			}
			if (object instanceof ProductCategory)
			{
				ProductCategory pg = (ProductCategory) object;
				return pg.getName();
			}
			if (object instanceof Brand)
			{
				return ((Brand) object).getName();
			}
			if (object instanceof Regulation)
			{
				return ((Regulation) object).getName();
			}
			if (object instanceof java.util.List)
			{
				java.util.List<Object> objectList = (java.util.List<Object>) object;
				if (objectList.size() == 0) return "";
				if (objectList.get(0) instanceof Brand)
				{
					StringBuffer stringBuffer = new StringBuffer();
					for (Iterator iterator = objectList.iterator(); iterator.hasNext();)
					{
						Brand brand = (Brand) iterator.next();
						stringBuffer.append(brand.getName());
						if (iterator.hasNext()) stringBuffer.append(", ");
					}
					return stringBuffer.toString();
				}
				if (objectList.get(0) instanceof Regulation)
				{
					StringBuffer stringBuffer = new StringBuffer();
					for (Iterator iterator = objectList.iterator(); iterator.hasNext();)
					{
						Regulation regulation = (Regulation) iterator.next();
						stringBuffer.append(regulation.getName());
						if (iterator.hasNext()) stringBuffer.append(", ");
					}
					return stringBuffer.toString();
				}
			}
			return object.toString().trim();
		}
	}
	
}
