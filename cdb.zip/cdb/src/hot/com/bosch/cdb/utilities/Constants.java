package com.bosch.cdb.utilities;

public class Constants {
	public static final String systemConfigEmailIntervall = "EMAIL_INTERVALL"; 
	public static final String systemConfigLastProcessedEmailTime = "LAST_PROCESSED_EMAIL_TIME"; 
}
