package com.bosch.cdb.utilities;


import static org.jboss.seam.annotations.Install.BUILT_IN;

import java.io.Serializable;
import java.util.Map;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Create;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Install;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.Startup;

@Name("applicationEnvironment")
@Scope(ScopeType.APPLICATION)
@Install(precedence = BUILT_IN)
@Startup
public class ApplicationEnvironment implements Serializable
{
  
	private static final long serialVersionUID = 8602041490840697201L;

	@In
    Map<String, String> messages;

    private String systemlink;
    private String environment;
    private String sendMail;
    private String hostName;
    private String serverPort;
    private String requestScheme;
       
    @Create
    public void init()
    {
        // determine runtime environment
        
        
        
        setEnvironment(System.getProperty("com.bosch.cdb.property.RUNTIME_ENVIRONMENT"));
       
        setHostName(System.getProperty("com.bosch.cdb.property.hostName"));
        setServerPort(System.getProperty("com.bosch.cdb.property.serverPort"));
        setRequestScheme(System.getProperty("com.bosch.cdb.property.requestScheme"));
        
        // read connection data to AR server depending on runtime environment
        sendMail = "true";
        
        if ("E".equalsIgnoreCase(getEnvironment()))
        {
            systemlink = messages.get("systemlink_E").trim();
            sendMail = messages.get("sendMail_E").trim();
            
        }
        else if ("D".equalsIgnoreCase(getEnvironment()))
        {
            systemlink = messages.get("systemlink_D").trim();
            sendMail = messages.get("sendMail_D").trim();
        }
        else if ("Q".equalsIgnoreCase(getEnvironment()))
        {
        	systemlink = messages.get("systemlink_Q").trim();
        	sendMail = messages.get("sendMail_Q").trim();
        }
        else if ("P".equalsIgnoreCase(getEnvironment()))
        {
        	systemlink = messages.get("systemlink_P").trim();
        	sendMail = messages.get("sendMail_P").trim();
        }
        else
        {
//            log.error("No valid Runtime Environment found. Current value is: " +platform);
            return;
        }
       
    }
    
    @Factory
	public String getFileRoot()
    {
    	String fileRoot =System.getProperty("com.bosch.cdb.property.file.root");
    	if(fileRoot==null || fileRoot.trim().length() == 0)
    	{
    		fileRoot = System.getProperty("file.root");
    	}	
		if (null == fileRoot || "".equals(fileRoot.trim()))
		{
			fileRoot="/bosch/files/cdb/";
		}
        return fileRoot;
    }
    
    public void reset()
    {
        systemlink = null;
        init();
    }
    
	public String getSystemlink()
	{
		return systemlink;
	}
	public void setSystemlink(String systemlink)
	{
		this.systemlink = systemlink;
	}
		
	public String getEnvironment()
	{
		return environment;
	}
	public void setEnvironment(String environment)
	{
		this.environment = environment;
	}
	public String getSendMail()
	{
		return sendMail;
	}
	public void setSendMail(String sendMail)
	{
		this.sendMail = sendMail;
	}
	public String getHostName()
	{
		return hostName;
	}
	public void setHostName(String hostName)
	{
		this.hostName = hostName;
	}
	public String getServerPort()
	{
		return serverPort;
	}
	public void setServerPort(String serverPort)
	{
		this.serverPort = serverPort;
	}
	public String getRequestScheme()
	{
		return requestScheme;
	}
	public void setRequestScheme(String requestScheme)
	{
		this.requestScheme = requestScheme;
	}

   
}
