package com.bosch.cdb.session;

import java.util.List;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.web.RequestParameter;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.log.Log;

import com.bosch.cdb.entity.Country;

/**
 * Business logic for management of countries.
 * @author ago8fe
*/
@Name("countryManager")
@Scope(ScopeType.CONVERSATION)
public class CountryManager 
{
	@Logger Log log;
	@In EntityManager entityManager;
	@In FacesMessages facesMessages;

	@RequestParameter(value="id") Long id;

	@Out(required=false)
	private List<Country> countryList;
	
	@In(required=false)
	@Out(required=false)
	private Country country;

	private void load() 
	{
		if (null == id)
		{
			return;
		}
		country = (Country) entityManager.find(Country.class, id);
		if (null == country)
		{
			facesMessages.addFromResourceBundle(Severity.WARN, "countryUnknown", id );
		}
	}

	@Factory(value="countryList")
	@SuppressWarnings("unchecked")
	public void queryCountryList()
	{
		countryList = entityManager.createQuery("select x from Country x order by x.name").getResultList();
	}
	
	public void viewCountryList()
	{
		queryCountryList();
	}
	
	public void createCountry()
	{
		country = new Country();
		country.setEditMode(true);
	}

	public void editCountry()
	{
		load();
		country.setEditMode(true);
	}

	public void viewCountry()
	{
		load();
		country.setEditMode(false);
	}

	public void saveCountry()
	{
		// save previously persisted
		if (null != country.getId())
		{
			entityManager.persist(country);
			facesMessages.addFromResourceBundle(Severity.INFO, "countrySaved", country.getId());
		}
		else
		{
			entityManager.persist(country);
			if (null != countryList)
			{
				countryList.add(country);
			}
			facesMessages.addFromResourceBundle(Severity.INFO, "countryCreated", country.getId());
		}
		country = null;
		
		entityManager.flush();
	}
	
	public void deleteCountry()
	{
		load();
		if (null == country) return;
		
		entityManager.remove(country);
		
		try
		{
			entityManager.flush();
		}
		catch (RuntimeException e)
		{
			facesMessages.addFromResourceBundle(Severity.INFO, "cantDeleteObject", country.getId());
			return;
		}

		if (null != countryList)
		{
			countryList.remove(country);
		}
		
		facesMessages.addFromResourceBundle(Severity.INFO, "countryDeleted", country.getId());
		country = null;
		entityManager.flush();
	}

}
