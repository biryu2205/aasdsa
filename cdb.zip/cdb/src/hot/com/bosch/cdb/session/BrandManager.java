package com.bosch.cdb.session;

import java.util.List;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.web.RequestParameter;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.log.Log;

import com.bosch.cdb.entity.Brand;

/**
 * Business logic for management of countries.
 * @author ago8fe
*/
@Name("brandManager")
@Scope(ScopeType.CONVERSATION)
public class BrandManager
{ 
	@Logger Log log;
	@In EntityManager entityManager;
	@In FacesMessages facesMessages;

	@RequestParameter(value="id") Long id;
	
	@In(required=false)
	@Out(required=false)
	private Brand brand;

	@Out(required=false)
	private List<Brand> brandList;

	
	private void load()
	{
		if (null == id)
		{
			return;
		}
		brand = (Brand) entityManager.find(Brand.class, id);
		if (null == brand)
		{
			facesMessages.addFromResourceBundle(Severity.WARN, "brandUnknown", id );
		}
	}
	
	@Factory(value="brandList")
	@SuppressWarnings("unchecked")
	public void queryBrandList()
	{
		brandList = entityManager.createQuery("select x from Brand x order by x.name").getResultList();
	}

	public void createBrand()
	{
		brand = new Brand();
		brand.setEditMode(true);
	}

	public void editBrand()
	{
		load();
		if (null == brand)
		{
			return;
		}
		brand.setEditMode(true);
	}

	public void viewBrand()
	{
		load();
		if (null == brand)
		{
			return;
		}
		brand.setEditMode(false);
	}
	
	public void viewBrandList()
	{
		queryBrandList();
	}

	public void saveBrand()
	{
		// save previously persisted
		if (null != brand.getId())
		{
			facesMessages.addFromResourceBundle(Severity.INFO, "brandSaved", brand.getId());
		}
		else
		{
			entityManager.persist(brand);
			if (null != brandList)
			{
				brandList.add(brand);
			}
			facesMessages.addFromResourceBundle(Severity.INFO, "brandCreated", brand.getId());
		}
		brand = null;
		
		entityManager.flush();
	}
	
	public void deleteBrand()
	{
		load();
		if (null == brand)
		{
			return;
		}
		entityManager.remove(brand);
		
		try
		{
			entityManager.flush();
		}
		catch (RuntimeException e)
		{
			facesMessages.addFromResourceBundle(Severity.INFO, "cantDeleteObject", brand.getId());
			return;
		}

		if (null != brandList) 
		{
			brandList.remove(brand);
		}
		
		facesMessages.addFromResourceBundle(Severity.INFO, "brandDeleted", brand.getId());
		
		brand = null;
	}

}
