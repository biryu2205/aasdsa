package com.bosch.cdb.session;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.NotSupportedException;
import javax.transaction.SystemException;

import org.jboss.seam.Component;
import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.Transactional;
import org.jboss.seam.contexts.Lifecycle;
import org.jboss.seam.transaction.UserTransaction;

import com.bosch.cdb.common.SystemCustomizing;
import com.bosch.cdb.utilities.Constants;


@Name("systemConfigurationManager")
@Scope(ScopeType.CONVERSATION)
public class SystemConfigurationManager {
	
	

	public void updateLastProcessedEmailTime()
	{
		 Lifecycle.beginCall();
         UserTransaction transaction = (UserTransaction) Component.getInstance("org.jboss.seam.transaction.transaction");
         try {
 			transaction.begin();
 		} catch (NotSupportedException e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		} catch (SystemException e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
         
         
         EntityManager entityManager = (EntityManager) Component.getInstance("entityManager");
         entityManager.joinTransaction();
		 Query query = entityManager.createNamedQuery("findSystemCustomizingByKey");
		 query.setParameter("key", Constants.systemConfigLastProcessedEmailTime);
		 SystemCustomizing sysconfi=(SystemCustomizing) query.getSingleResult();
         
         entityManager.joinTransaction();
          
         sysconfi.setValue((new SimpleDateFormat("yyyy/MM/dd")).format(Calendar.getInstance().getTime()));
         entityManager.flush();
         Lifecycle.endCall();
	}
}
