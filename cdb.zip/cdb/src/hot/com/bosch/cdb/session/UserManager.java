package com.bosch.cdb.session;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.List;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.SizeLimitExceededException;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.web.RequestParameter;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.log.Log;

import com.bosch.commons.security.CustomIdentity;
import com.bosch.commons.security.Role;
import com.bosch.commons.security.User;

/**
 * Business logic to manage the users.
 * 
 * @author ago8fe
 * @author noh8fe
 */
@Name("userManager")
@Scope(ScopeType.CONVERSATION)
public class UserManager implements Serializable
{
	private static final long serialVersionUID = -3029541938819807753L;

	@Logger Log log;
	@In EntityManager entityManager;
	@In FacesMessages facesMessages;
	@In CustomIdentity identity;

	@RequestParameter(value="id") Long id;
	
	@In(required = false)
	@Out(required = false)
	private User selectedUser;
	
	@In(required=false)
	@Out(required=false)
	private List<User> userList;
    
	private String newUsername = "";
	
	// constant values for the BCD access
	private static final String BCD_DEPARTMENT = "department";
	private static final String BCD_FIRSTNAME  = "givenName";
	private static final String BCD_LASTNAME   = "sn";
	private static final String BCD_USER_NAME  = "sAMAccountName";
	private static final String BCD_MAIL       = "mail";
	
	private void load()
	{
		if (null == id)
		{
			return;
		}
		selectedUser = (User) entityManager.find(User.class, id);
		if (null == selectedUser)
		{
			facesMessages.addFromResourceBundle(Severity.WARN, "userNotFound", id );
		}
	}
	
	/**
	 * Retrieves all users.
	 */
	@Factory(value="userList")
	@SuppressWarnings("unchecked")
	public void findUsers()
	{
		userList = entityManager.createQuery("select u from User u").getResultList();
	}

	/**
	 * Edit user action.
	 */
	public void editUser()
	{
		load();
	}


	/**
	 * Creates a user for the given user name with the data from the BCD but does not persist the user.
	 * @return User
	 */
	@SuppressWarnings("unchecked")
	public String createUser()
	{
		log.debug("Try to load User for user name: {0}", newUsername);
		List<User> userList = entityManager.createQuery("select u from User u where u.userName=:userName").setParameter("userName", newUsername).getResultList();
		
		if (userList.size() == 1)
		{
			facesMessages.addFromResourceBundle(Severity.WARN, "userExists", newUsername);
			return "list";
		}
		
		if (userList.size() > 1)
		{
			facesMessages.addFromResourceBundle(Severity.ERROR, "userExistsDuplicate", newUsername);
			return "list";
		}
		
		User user = lookupUserInBcd(newUsername);
		
		if (user == null)
		{
			facesMessages.addFromResourceBundle(Severity.WARN, "userNotFound", newUsername);
			return "list";
		}
		
		facesMessages.addFromResourceBundle(Severity.INFO, "userFound", newUsername);
		newUsername = "";
		selectedUser = user;
		return "detail";
	}


	/**
	 * Saves the user.
	 */
	public void saveUser()
	{
		if (selectedUser == null)
		{
			log.error("The selected user is null");
			return;
		}
		
		if (selectedUser.getUserName() != null && selectedUser.getUserName() != selectedUser.getUserName().toLowerCase())
		{
			selectedUser.setUserName(selectedUser.getUserName().toLowerCase());
		}
		
		if (selectedUser.getId() == null)
		{
			entityManager.merge(selectedUser);
			logUserAdministration("creates", selectedUser);
			facesMessages.addFromResourceBundle(Severity.INFO, "userSavedNew", selectedUser.getUserName());
		}
		else
		{
			entityManager.merge(selectedUser);
			logUserAdministration(" saves ", selectedUser);
			facesMessages.addFromResourceBundle(Severity.INFO, "userSaved", selectedUser.getUserName());
		}

		entityManager.flush();

		// refresh the user list
		findUsers();
		selectedUser = null;
	}

	
	/**
	 * Deletes the user.
	 */
	public void deleteUser()
	{
		load();

		if (null == selectedUser) return;

		entityManager.remove(selectedUser);

		try
		{
			entityManager.flush();
		}
		catch (RuntimeException e)
		{
			facesMessages.addFromResourceBundle(Severity.INFO, "cantDeleteObject", selectedUser.getId());
			return;
		}

		
		logUserAdministration("deletes", selectedUser);
		facesMessages.addFromResourceBundle(Severity.INFO, "userDeleted", selectedUser.getUserName());
		
		// refresh the user list
		findUsers();
		
		selectedUser = null;
	}

	/**
	 * Logs the modification of deletion of an user to a separate log file defined in log4j.xml.
	 * The user name of the actor is displayed if the actor is logged in, else 'ANONYM' is displayed.
	 * In this sample application also user who are not logged in are able to administer users.
	 * 
	 * @param action The string to be displayed in the log (e.g. 'creates', 'saves', 'deletes')
	 * @param user   The user 
	 */
	private void logUserAdministration( String action, User user)
	{
		String username = (identity.isLoggedIn() ? identity.getUsername() : "ANONYM");
		log.info("{0} {1} the user: '{2}'", username, action, user.toString());
	}
	
	
	/**
	 * Lookup for a user with the given user name.
	 * @return User
	 */
	private User lookupUserInBcd(String userName)
	{
		try
		{
			String base = "";
			StringBuilder filter = new StringBuilder();
			filter.append("(&(objectClass=user)(").append(BCD_USER_NAME).append("=").append(userName).append("))");
			String[] retAttrNames = { BCD_USER_NAME, BCD_LASTNAME, BCD_FIRSTNAME, BCD_DEPARTMENT,BCD_MAIL};
			int countLimit = 1;

			SearchControls sc = new SearchControls();
			sc.setSearchScope(SearchControls.SUBTREE_SCOPE);
			sc.setReturningAttributes(retAttrNames);
			sc.setReturningObjFlag(true);
			sc.setCountLimit(countLimit);

			NamingEnumeration<SearchResult> resultEnum = getDirContext().search(base, filter.toString(), sc);

			if (resultEnum.hasMore())
			{
				SearchResult searchResult = resultEnum.next();
				Attributes attrs = searchResult.getAttributes();
				String bcdUserName = null;
				String bcdFirstName = null;
				String bcdLastName = null;
				String bcdDepartment = null;
				String bcdMail = null;
				
				if (attrs.get(BCD_USER_NAME) != null)
				{
					bcdUserName = (String) attrs.get(BCD_USER_NAME).get(0);
				}
					
				
				if (attrs.get(BCD_FIRSTNAME) != null)
				{
					bcdFirstName = (String) attrs.get(BCD_FIRSTNAME).get(0);
				}
					
				
				if (attrs.get(BCD_LASTNAME) != null)
				{
					bcdLastName = (String) attrs.get(BCD_LASTNAME).get(0);
				}
					
				
				if (attrs.get(BCD_DEPARTMENT) != null)
				{
					bcdDepartment = (String) attrs.get(BCD_DEPARTMENT).get(0);
				}
					
				
				if (attrs.get(BCD_MAIL) != null)
				{
					bcdMail = (String) attrs.get(BCD_MAIL).get(0);
				}
					
					return new User(bcdUserName.toLowerCase(), bcdLastName,
							bcdFirstName, bcdDepartment,bcdMail);
			}
		}
		catch (SizeLimitExceededException e)
		{
			log.debug("LDAP-Search: Size Limit Exceeded.");
		}
		catch (NamingException e)
		{
			log.debug("LDAP-Search: Naming Exception.", e);
		}
		return null;
	}
	
	
	/**
	 * BCD context information.
	 * @return DirContext
	 */
	private DirContext getDirContext()
	{
		boolean sslEnabled = false;
		String principal = "bu91fe@de.bosch.com";
		String credentials = "darf!nix";
		
		Hashtable<String, String> props = new Hashtable<String, String>();
		props.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		props.put(Context.SECURITY_AUTHENTICATION, "simple");
		props.put(Context.SECURITY_PRINCIPAL, principal);
		props.put(Context.SECURITY_CREDENTIALS, credentials);
		props.put(Context.PROVIDER_URL, "ldap://rb-bcd-gc-defe-luds-lb.rb-dirsvc.bosch-org.com:3268/DC=bosch,DC=com");
		
		if (sslEnabled)
		{
			props.put(Context.SECURITY_PROTOCOL, "ssl");
		}
		
		try
		{
			return new InitialDirContext(props);
		}
		catch (NamingException e)
		{
			log.fatal("InitialDirContext for LDAP connection could not be instanciated.", e);
		}
		return null;
	};
	
	
	/**
	 * Determines all roles. Then the roles can be assigned to a user in the userDetail page.
	 * @Return List of Role
	 */
	@Factory(value="roleList")
	@SuppressWarnings("unchecked")
	public List<Role> findRoles()
	{
		return entityManager.createQuery("select r from Role r").getResultList();
	}
	
	public String getNewUsername()
	{
		return newUsername;
	}
	
	public void setNewUsername(String newUsername)
	{
		this.newUsername = newUsername;
	}
	
	public CustomIdentity getIdentity()
	{
		return identity;
	}


	public void setIdentity(CustomIdentity identity)
	{
		this.identity = identity;
	}

	
}