package com.bosch.cdb.session;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.log.Log;

import com.bosch.cdb.entity.Novelty;

/**
 * Business logic for management of novelties.
 * @author ago8fe
*/
@Name("noveltyManager")
@Scope(ScopeType.CONVERSATION)
public class NoveltyManager 
{
	@Logger Log log;
	@In EntityManager entityManager;
	@In FacesMessages facesMessages;

	@In(required=false)
	private Novelty novelty;

	@Factory
	public Novelty getNovelty()
	{
		novelty = (Novelty) entityManager.find(Novelty.class, new Long(1));
		if (null == novelty)
		{
			novelty = new Novelty();
			novelty.setId(new Long(1));
		}
		return novelty;
	}

	public void saveNovelty()
	{
			facesMessages.addFromResourceBundle(Severity.INFO, "noveltySaved");
			entityManager.flush();
	}

}
