package com.bosch.cdb.session;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.web.RequestParameter;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.log.Log;

import com.bosch.cdb.entity.Brand;
import com.bosch.cdb.entity.Product;
import com.bosch.cdb.entity.ProductCategory;
import com.bosch.cdb.report.PdfCreator;
import com.bosch.commons.security.CustomIdentity;
import com.lowagie.text.DocumentException;

/**
 * Business logic for management of products.
 * @author ago8fe
*/
@Name("productManager")
@Scope(ScopeType.CONVERSATION)
public class ProductManager 
{
	@Logger Log log;
	@In EntityManager entityManager;
	@In FacesMessages facesMessages;
    @In CustomIdentity identity;

	@RequestParameter(value="id") Long id;

	@In(create=true) ProductCategoryManager productCategoryManager;
    @In(create=true) PdfCreator pdfCreator;
	
	@In(required=false)
	@Out(required=false)
	private Product product;

	@Out(required=false)
	private List<Product> productList;
	
	private ProductCategory filterProductCategory;
	
	private Brand filterBrand;

	private String filterProductName;

	private void load()
	{
		if (null == id)
		{
			return;
		}
			product = (Product) entityManager.find(Product.class, id);
			if (null == product)
			{
				facesMessages.addFromResourceBundle(Severity.WARN, "productUnknown", id );
			}
	}

	public void print() throws IOException, DocumentException
	{
		load();
		pdfCreator.print(product);
	}
	@Factory(value="productList")
	@SuppressWarnings("unchecked")
	public void queryProductList()
	{
		String filterExpression = " where 0=0 ";
		
		if (null != filterBrand)
		{
			filterExpression += " and :filterBrand member of x.brandList ";
		}

		if (null != filterProductCategory)
		{
			filterExpression += " and :filterProductCategory = x.productCategory ";
		}

		String filterProductNamePattern = null;
		if (null != filterProductName && !"".equals(filterProductName.trim()))
		{
			filterProductNamePattern = "%" + filterProductName.toLowerCase() + "%";
			filterExpression += " and LOWER(x.name) like :filterProductNamePattern ";
		}

		Query query = entityManager.createQuery("select x from Product x " + filterExpression + " order by x.name");

		if (null != filterBrand)
		{
			query.setParameter("filterBrand", filterBrand);
		}
		if (null != filterProductCategory)
		{
			query.setParameter("filterProductCategory", filterProductCategory);
		}
		if (null != filterProductNamePattern)
		{
			query.setParameter("filterProductNamePattern", filterProductNamePattern);
		}
		
		productList = query.getResultList();

	}
	
	public void queryAllProducts()
	{
		setFilterBrand(null);
		setFilterProductCategory(null);
		queryProductList();
	}
	
	public void createProduct()
	{
		product = new Product();
		product.setCreateDate(new Date());
		product.setUpdateDate(new Date());
		product.setCreateUser(identity.getUser());
		product.setUpdateUser(identity.getUser());
		product.setEditMode(true);
	}

	public void editProduct()
	{
		load();
		product.setEditMode(true);
	}

	public void viewProduct()
	{
		load();
		product.setEditMode(false);
	}

	public void saveProduct()
	{
		// save previously persisted
		if (null != product.getId())
		{
			product.setUpdateDate(new Date());
			product.setUpdateUser(identity.getUser());
			entityManager.persist(product);
			facesMessages.addFromResourceBundle(Severity.INFO, "productSaved", product.getId());
		}
		else
		{
			entityManager.persist(product);
			if (null != productList)
			{
				productList.add(product);
			}
			facesMessages.addFromResourceBundle(Severity.INFO, "productCreated", product.getId());
		}

		entityManager.flush();
	}
	
	public void deleteProduct()
	{
		load();
		
		if (null == product) return;
		
		entityManager.remove(product);
		
		try
		{
			entityManager.flush();
		}
		catch (RuntimeException e)
		{
			facesMessages.addFromResourceBundle(Severity.INFO, "cantDeleteProduct", product.getId());
			return;
		}

		
		if (null != productList)
		{
			productList.remove(product);
		}
		facesMessages.addFromResourceBundle(Severity.INFO, "productDeleted", product.getId());
		product = null;
	}
	
	public void resetFilters()
	{
		setFilterBrand(null);
		setFilterProductCategory(null);
	}
	
	public void viewProductListResetFilters()
	{
		resetFilters();
		viewProductList();
	}

	public void viewProductList()
	{
		productCategoryManager.resetFilters();
		productCategoryManager.queryProductCategoryList();
		
		queryProductList();
	}

	public ProductCategory getFilterProductCategory()
	{
		return filterProductCategory;
	}

	public void setFilterProductCategory(ProductCategory filterProductCategory)
	{
		this.filterProductCategory = filterProductCategory;
	}

	public Brand getFilterBrand()
	{
		return filterBrand;
	}

	public void setFilterBrand(Brand filterBrand)
	{
		this.filterBrand = filterBrand;
	}

	public String getFilterProductName()
	{
		return filterProductName;
	}

	public void setFilterProductName(String filterProductName)
	{
		this.filterProductName = filterProductName;
	}

}
