package com.bosch.cdb.session;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.web.RequestParameter;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.log.Log;

import com.bosch.cdb.entity.Country;
import com.bosch.cdb.entity.Institute;
import com.bosch.cdb.entity.Regulation;
import com.bosch.cdb.report.PdfCreator;
import com.bosch.commons.security.CustomIdentity;
import com.lowagie.text.DocumentException;

/**
 * Business logic for management of institutes.
 * @author ago8fe
*/
@Name("instituteManager")
@Scope(ScopeType.CONVERSATION)
public class InstituteManager 
{
	@Logger Log log;
	@In EntityManager entityManager;
	@In FacesMessages facesMessages;
    @In CustomIdentity identity;

	@RequestParameter(value="id") Long id;
	
	private Country filterCountry;
	private Regulation filterRegulation;

	private Date filterCreateDateFrom;
	private Date filterCreateDateTo;
	private Date filterUpdateDateFrom;
	private Date filterUpdateDateTo;
	private Boolean filterUpdateDateNotInInterval;
	private String filterSubstring;

	@In(create=true) RegulationManager regulationManager;
	@In(create=true) PdfCreator pdfCreator;
	
	@In(required=false)
	@Out(required=false)
	private Institute institute;

	@Out(required=false)
	private List<Institute> instituteList;

	public void queryRegulationList()
	{
		List<Country> countryList = institute.getCountryList();
		regulationManager.queryRegulationList(countryList);
	}
	
	private void load()
	{
		if (null == id)
		{
			return;
		}
		institute = (Institute) entityManager.find(Institute.class, id);
		if (null == institute)
		{
			facesMessages.addFromResourceBundle(Severity.WARN, "instituteUnknown", id );
		}
	}

	public void print() throws IOException, DocumentException
	{
		load();
		pdfCreator.print(institute);
	}
	
	public void resetFilters()
	{
		setFilterCountry(null);
		setFilterRegulation(null);
		setFilterCreateDateFrom(null);
		setFilterCreateDateTo(null);
		setFilterUpdateDateFrom(null);
		setFilterUpdateDateTo(null);
		setFilterUpdateDateNotInInterval(null);
		setFilterSubstring(null);
	}
	
	public void viewInstituteListResetFilters()
	{
		resetFilters();
		viewInstituteList();
	}

	public void viewInstituteList()
	{
		regulationManager.resetFilters();
		regulationManager.queryRegulationList();
		
		queryInstituteList();
	}

	@Factory(value="instituteList")
	@SuppressWarnings("unchecked")
	public void queryInstituteList()
	{
		
		String filterExpression = " where 0=0 ";
		if (null != filterCountry)
		{
			filterExpression += " and :filterCountry member of x.countryList ";
		}
		if (null != filterRegulation)
		{
			filterExpression += " and :filterRegulation member of x.regulationList ";
		}

		if (null != filterCreateDateFrom)
		{
			filterExpression += " and :filterCreateDateFrom <= x.createDate ";
		}
		if (null != filterCreateDateTo)
		{
			filterExpression += " and :filterCreateDateTo >= x.createDate ";
		}
		
		if (null == filterUpdateDateNotInInterval || filterUpdateDateNotInInterval.equals(Boolean.FALSE))
		{
			if (null != filterUpdateDateFrom)
			{
				filterExpression += " and :filterUpdateDateFrom <= x.updateDate ";
			}
			if (null != filterUpdateDateTo)
			{
				filterExpression += " and :filterUpdateDateTo >= x.updateDate ";
			}
		}
		else
		{
			if(null != filterUpdateDateFrom || null != filterUpdateDateTo)
			{
				filterExpression += " and ( ";
				
				if (null != filterUpdateDateFrom)
				{
					filterExpression += " :filterUpdateDateFrom > x.updateDate ";
				}
				
				if (null != filterUpdateDateFrom && null != filterUpdateDateTo)
				{
					filterExpression += " or ";
				}
				
				if (null != filterUpdateDateTo)
				{
					filterExpression += " :filterUpdateDateTo < x.updateDate ";
				}			
				
				filterExpression += " or x.updateDate = null ) ";
			}
		}

		String filterSubstringPattern = null;
		if (null != filterSubstring && !"".equals(filterSubstring.trim()))
		{
			filterSubstringPattern = "%" + filterSubstring.toLowerCase() + "%";
			filterExpression += " and ( exists (select c from Country c where LOWER(c.code) like :filterSubstringPattern and c member of x.countryList) " +
					"OR LOWER(x.name) like :filterSubstringPattern or LOWER(x.remark) like :filterSubstringPattern or LOWER(x.contact) like :filterSubstringPattern or LOWER(x.contactPerson) like :filterSubstringPattern) ";
		}
		Query query = entityManager.createQuery("select x from Institute x " + filterExpression + " order by x.name");
		
		if (null != filterCountry)
		{
			query.setParameter("filterCountry", filterCountry);
		}
		if (null != filterRegulation)
		{
			query.setParameter("filterRegulation", filterRegulation);
		}

		if (null != filterCreateDateFrom)
		{
			query.setParameter("filterCreateDateFrom", filterCreateDateFrom);
		}
		if (null != filterCreateDateTo)
		{
			filterCreateDateTo.setHours(23);
			filterCreateDateTo.setMinutes(59);
			query.setParameter("filterCreateDateTo", filterCreateDateTo);
		}

		if (null != filterUpdateDateFrom)
		{
			query.setParameter("filterUpdateDateFrom", filterUpdateDateFrom);
		}
		if (null != filterUpdateDateTo)
		{
			filterUpdateDateTo.setHours(23);
			filterUpdateDateTo.setMinutes(59);
			query.setParameter("filterUpdateDateTo", filterUpdateDateTo);
		}
		
		if (null != filterSubstringPattern)
		{
			query.setParameter("filterSubstringPattern", filterSubstringPattern);
		}
		instituteList = query.getResultList();

	}
	
	public void createInstitute()
	{
		institute = new Institute();
		institute.setCreateDate(new Date());
		institute.setUpdateDate(new Date());
		institute.setCreateUser(identity.getUser());
		institute.setUpdateUser(identity.getUser());
		institute.setEditMode(true);
		institute.setRegulationList(new ArrayList<Regulation>());
	}

	public void editInstitute()
	{
		load();
		institute.setEditMode(true);
	}

	public void viewInstitute()
	{
		load();
		institute.setEditMode(false);
	}

	public void saveInstitute()
	{
		// save previously persisted
		if (null != institute.getId())
		{
			institute.setUpdateDate(new Date());
			institute.setUpdateUser(identity.getUser());
			entityManager.persist(institute);
			facesMessages.addFromResourceBundle(Severity.INFO, "instituteSaved", institute.getId());
		}
		else
		{
			entityManager.persist(institute);
			if (null != instituteList)
			{
				instituteList.add(institute);
			}
			facesMessages.addFromResourceBundle(Severity.INFO, "instituteCreated", institute.getId());
		}

		entityManager.flush();
	}
	
	public void deleteInstitute()
	{
		load();
		if (null == institute) return;
		entityManager.remove(institute);
		
		try
		{
			entityManager.flush();
		}
		catch (RuntimeException e)
		{
			facesMessages.addFromResourceBundle(Severity.INFO, "cantDeleteObject", institute.getId());
			return;
		}

		if (null != instituteList)
		{
			instituteList.remove(institute);
		}
		
		facesMessages.addFromResourceBundle(Severity.INFO, "instituteDeleted", institute.getId());
		institute = null;
	}
	
	public Country getFilterCountry()
	{
		return filterCountry;
	}


	public void setFilterCountry(Country filterCountry)
	{
		this.filterCountry = filterCountry;
	}


	public Regulation getFilterRegulation()
	{
		return filterRegulation;
	}


	public void setFilterRegulation(Regulation filterRegulation)
	{
		this.filterRegulation = filterRegulation;
	}

	public Date getFilterCreateDateFrom()
	{
		return filterCreateDateFrom;
	}

	public void setFilterCreateDateFrom(Date filterCreateDateFrom)
	{
		this.filterCreateDateFrom = filterCreateDateFrom;
	}

	public Date getFilterCreateDateTo()
	{
		return filterCreateDateTo;
	}

	public void setFilterCreateDateTo(Date filterCreateDateTo)
	{
		this.filterCreateDateTo = filterCreateDateTo;
	}

	public Date getFilterUpdateDateFrom()
	{
		return filterUpdateDateFrom;
	}

	public void setFilterUpdateDateFrom(Date filterUpdateDateFrom)
	{
		this.filterUpdateDateFrom = filterUpdateDateFrom;
	}

	public Date getFilterUpdateDateTo()
	{
		return filterUpdateDateTo;
	}

	public void setFilterUpdateDateTo(Date filterUpdateDateTo)
	{
		this.filterUpdateDateTo = filterUpdateDateTo;
	}

	public Boolean getFilterUpdateDateNotInInterval()
	{
		return filterUpdateDateNotInInterval;
	}

	public void setFilterUpdateDateNotInInterval(
			Boolean filterUpdateDateNotInInterval)
	{
		this.filterUpdateDateNotInInterval = filterUpdateDateNotInInterval;
	}

	public String getFilterSubstring()
	{
		return filterSubstring;
	}

	public void setFilterSubstring(String filterSubstring)
	{
		this.filterSubstring = filterSubstring;
	}
	
}
