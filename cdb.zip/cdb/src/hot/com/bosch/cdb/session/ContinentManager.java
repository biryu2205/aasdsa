package com.bosch.cdb.session;

import java.util.List;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.log.Log;

import com.bosch.cdb.entity.Continent;

/**
 * Business logic for management of countries.
 * @author ago8fe
*/
@Name("continentManager")
@Scope(ScopeType.CONVERSATION)
public class ContinentManager 
{
	@Logger Log log;
	@In EntityManager entityManager;
	@In FacesMessages facesMessages;
	
	@Factory(value="continentList")
	@SuppressWarnings("unchecked")
	public List<Continent> queryContinentList()
	{
		return entityManager.createQuery("select x from Continent x order by x.name").getResultList();
	}
	
	public void viewContinentList()
	{
		// no logic
	}

}
