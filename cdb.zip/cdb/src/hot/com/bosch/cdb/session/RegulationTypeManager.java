package com.bosch.cdb.session;

import java.util.List;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.web.RequestParameter;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.log.Log;

import com.bosch.cdb.entity.RegulationType;

/**
 * Business logic for management of standards.
 * @author ago8fe
*/
@Name("regulationTypeManager")
@Scope(ScopeType.CONVERSATION)
public class RegulationTypeManager
{
	@Logger Log log;
	@In EntityManager entityManager;
	@In FacesMessages facesMessages;

	@RequestParameter(value="id") Long id;
	
	@In(required=false)
	@Out(required=false)
	private RegulationType regulationType;

	@Out(required=false)
	private List<RegulationType> regulationTypeList;

	private void load()
	{
		if (null == id)
		{
			return;
		}
		regulationType = (RegulationType) entityManager.find(RegulationType.class, id);
		if (null == regulationType)
		{
			facesMessages.addFromResourceBundle(Severity.WARN, "regulationTypeUnknown", id );
		}
	}
	
	@Factory(value="regulationTypeList")
	@SuppressWarnings("unchecked")
	public void queryRegulationTypeList()
	{
		regulationTypeList = entityManager.createQuery("select x from RegulationType x order by x.name").getResultList();
	}

	public void createRegulationType()
	{
		regulationType = new RegulationType();
		regulationType.setEditMode(true);
	}

	public void editRegulationType()
	{
		load();
		regulationType.setEditMode(true);
	}

	public void viewRegulationType()
	{
		load();
		regulationType.setEditMode(false);
	}

	public void saveRegulationType()
	{
		// save previously persisted
		if (null != regulationType.getId())
		{
			entityManager.persist(regulationType);
			facesMessages.addFromResourceBundle(Severity.INFO, "regulationTypeSaved", regulationType.getId());
		}
		else
		{
			entityManager.persist(regulationType);
			if (null != regulationTypeList)
			{
				regulationTypeList.add(regulationType);
			}
			facesMessages.addFromResourceBundle(Severity.INFO, "regulationTypeCreated", regulationType.getId());
		}
		regulationType = null;
		entityManager.flush();
	}
	
	public void deleteRegulationType()
	{
		load();
		
		if (null == regulationType) return;
		
		entityManager.remove(regulationType);

		try
		{
			entityManager.flush();
		}
		catch (RuntimeException e)
		{
			facesMessages.addFromResourceBundle(Severity.INFO, "cantDeleteObject", regulationType.getId());
			return;
		}

		if (null != regulationTypeList)
		{
			regulationTypeList.remove(regulationType);
		}
		
		facesMessages.addFromResourceBundle(Severity.INFO, "regulationTypeDeleted", regulationType.getId());
		regulationType = null;
	}
	
	public void viewRegulationTypeList()
	{
		queryRegulationTypeList();
	}

}
