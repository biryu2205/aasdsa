package com.bosch.cdb.session;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.web.RequestParameter;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.log.Log;

import com.bosch.cdb.UploadFile;
import com.bosch.cdb.entity.Country;
import com.bosch.cdb.entity.Document;
import com.bosch.cdb.entity.Information;
import com.bosch.cdb.entity.InformationType;
import com.bosch.cdb.report.PdfCreator;
import com.bosch.common.ApplicationUtil;
import com.bosch.commons.security.CustomIdentity;
import com.lowagie.text.DocumentException;

/**
 * Business logic for management of directives.
 * @author ago8fe
*/
@Name("informationManager")
@Scope(ScopeType.CONVERSATION)
public class InformationManager 
{
	@Logger Log log;
	@In EntityManager entityManager;
	@In FacesMessages facesMessages;
    @In CustomIdentity identity;

    @In(create=true) PdfCreator pdfCreator;
	@In(create=true) DocumentManager documentManager;

	@RequestParameter(value="id") Long id;
	@RequestParameter(value="documentId") Long documentId;

	@In(required=false)
	@Out(required=false)
	private Information information;

	@Out(required=false)
	private List<Information> informationList;

	private InformationType filterInformationType;
	
	private Country filterCountry;
	
	private Date filterCreateDateFrom;
	private Date filterCreateDateTo;
	private Date filterUpdateDateFrom;
	private Date filterUpdateDateTo;
	private Boolean filterUpdateDateNotInInterval;
	private String filterSubstring;

	private UploadFile document = new UploadFile();

	private void load()
	{
		if (null == id)
		{
			return;
		}
		information = (Information) entityManager.find(Information.class, id);
		if (null == information)
		{
			facesMessages.addFromResourceBundle(Severity.WARN, "informationUnknown", id );
		} else {
			List<Document> oldDocs = information.getDocumentList();
			information.setDocumentList(ApplicationUtil.getListDocument(documentManager ,oldDocs));
		}
	}

	@Factory(value="informationList")
	@SuppressWarnings("unchecked")
	public void queryInformationList()
	{
		String filterExpression = " where 0=0 ";
		if (null != filterInformationType)
		{
			filterExpression += " and informationType = :filterInformationType"; 
		}
		if (null != filterCountry)
		{
			filterExpression += " and :filterCountry member of x.countryList ";
		}

		if (null != filterCreateDateFrom)
		{
			filterExpression += " and :filterCreateDateFrom <= x.createDate ";
		}
		if (null != filterCreateDateTo)
		{
			filterExpression += " and :filterCreateDateTo >= x.createDate ";
		}
		
		if (null == filterUpdateDateNotInInterval || filterUpdateDateNotInInterval.equals(Boolean.FALSE))
		{
			if (null != filterUpdateDateFrom)
			{
				filterExpression += " and :filterUpdateDateFrom <= x.updateDate ";
			}
			if (null != filterUpdateDateTo)
			{
				filterExpression += " and :filterUpdateDateTo >= x.updateDate ";
			}
		}
		else
		{
			if(null != filterUpdateDateFrom || null != filterUpdateDateTo)
			{
				filterExpression += " and ( ";
				
				if (null != filterUpdateDateFrom)
				{
					filterExpression += " :filterUpdateDateFrom > x.updateDate ";
				}
				
				if (null != filterUpdateDateFrom && null != filterUpdateDateTo)
				{
					filterExpression += " or ";
				}
				
				if (null != filterUpdateDateTo)
				{
					filterExpression += " :filterUpdateDateTo < x.updateDate ";
				}			
				
				filterExpression += " or x.updateDate = null ) ";
			}
		}

		String filterSubstringPattern = null;
		if (null != filterSubstring && !"".equals(filterSubstring.trim()))
		{
			filterSubstringPattern = "%" + filterSubstring.toLowerCase() + "%";
			filterExpression += " and ( exists (select c from Country c where LOWER(c.code) like :filterSubstringPattern and c member of x.countryList) " +
					"OR LOWER(x.name) like :filterSubstringPattern or LOWER(x.remark) like :filterSubstringPattern) ";
		}

		Query query = entityManager.createQuery("select x from Information x " + filterExpression + " order by x.name");

		if (null != filterInformationType)
		{
			query.setParameter("filterInformationType", filterInformationType);
		}
		if (null != filterCountry)
		{
			query.setParameter("filterCountry", filterCountry);
		}
		if (null != filterCreateDateFrom)
		{
			query.setParameter("filterCreateDateFrom", filterCreateDateFrom);
		}
		if (null != filterCreateDateTo)
		{
			filterCreateDateTo.setHours(23);
			filterCreateDateTo.setMinutes(59);
			query.setParameter("filterCreateDateTo", filterCreateDateTo);
		}

		if (null != filterUpdateDateFrom)
		{
			query.setParameter("filterUpdateDateFrom", filterUpdateDateFrom);
		}
		if (null != filterUpdateDateTo)
		{
			filterUpdateDateTo.setHours(23);
			filterUpdateDateTo.setMinutes(59);
			query.setParameter("filterUpdateDateTo", filterUpdateDateTo);
		}
		
		if (null != filterSubstringPattern)
		{
			query.setParameter("filterSubstringPattern", filterSubstringPattern);
		}


		informationList = query.getResultList();
	}

	public void queryInformationListUsingInformationTypes()
	{

		Query query = entityManager.createQuery("select x from Information x where x.informationType.id = 2 or x.informationType.id = 3 or x.informationType.id = 4 or x.informationType.id = 1000 order by x.name");
		informationList = query.getResultList();
	}
	
	public void queryInformationList(List<Country> countryList)
	{
		if (null == countryList || countryList.isEmpty())
		{
			informationList = new ArrayList<Information>();
			return;
		}
		String filterExpression = " where ";
		int i = 0;
		for (Country country : countryList)
		{
			String number = (new Integer(i)).toString().trim();
			if (i > 0)
			{
				filterExpression += " or ";
			}
			filterExpression += " :country" + number + " member of x.countryList ";
			i++;
		}

		Query query = entityManager.createQuery("select x from Information x " + filterExpression + " order by x.name");

		i = 0;
		for (Country country : countryList)
		{
			String number = (new Integer(i)).toString().trim();
			if (i > 0)
			{
				filterExpression += " or ";
			}
			query.setParameter("country" + number, country);
			i++;
		}

		informationList = query.getResultList();
	}

	public void deleteDocument()
	{
		Document document = documentManager.getDocument(documentId);
		if (null != document)
		{
			information.getDocumentList().remove(document);
			entityManager.flush();
		}
	}

	public void createInformation()
	{
		information = new Information();
		information.setCreateDate(new Date());
		information.setUpdateDate(new Date());
		information.setCreateUser(identity.getUser());
		information.setUpdateUser(identity.getUser());
		information.setEditMode(true);
	}

	public void editInformation()
	{
		load();
		if (null == information)
		{
			return;
		}
		information.setEditMode(true);
	}
	
	public void print() throws IOException, DocumentException
	{
		load();
		pdfCreator.print(information);
	}

	public void viewInformation()
	{
		load();
		if (null != information)
		{
			information.setEditMode(false);
			Collections.sort(information.getCountryList());
		}
	}

	private void createDocuments() throws IOException
	{
		
		if (!document.isEmpty())
		{
			Document tmpDoc = new Document(information.getPrefixedId(), document);
			information.getDocumentList().add(tmpDoc);
		}
	}

	public void saveInformation() throws IOException
	{
		// save previously persisted
		if (null != information.getId())
		{
			information.setUpdateDate(new Date());
			information.setUpdateUser(identity.getUser());
			createDocuments();
			facesMessages.addFromResourceBundle(Severity.INFO, "informationSaved", information.getId());
		}
		else
		{
			entityManager.persist(information);
			createDocuments();
			if (null != informationList)
			{
				informationList.add(information);
			}
			facesMessages.addFromResourceBundle(Severity.INFO, "informationCreated", information.getId());
		}
		entityManager.flush();
	}
	
	public void deleteInformation()
	{
		load();
		
		if (null == information)	return;
		
		entityManager.remove(information);
		
		try
		{
			entityManager.flush();
		}
		catch (RuntimeException e)
		{
			facesMessages.addFromResourceBundle(Severity.INFO, "informationCantDelete", information.getId());
			return;
		}
		
		if (null != informationList)
		{
			informationList.remove(information);
		}
		
		facesMessages.addFromResourceBundle(Severity.INFO, "informationDeleted", information.getId());
		information = null;
	}
	
	public void resetFilters()
	{
		setFilterCountry(null);
		setFilterInformationType(null);
		setFilterCreateDateFrom(null);
		setFilterCreateDateTo(null);
		setFilterUpdateDateFrom(null);
		setFilterUpdateDateTo(null);
		setFilterUpdateDateNotInInterval(null);
		setFilterSubstring(null);
	}

	public void viewInformationListResetFilters()
	{
		resetFilters();
		queryInformationList();
	}

	public void viewInformationList()
	{
		queryInformationList();
	}

	public InformationType getFilterInformationType()
	{
		return filterInformationType;
	}


	public void setFilterInformationType(InformationType filterInformationType)
	{
		this.filterInformationType = filterInformationType;
	}

	public Country getFilterCountry()
	{
		return filterCountry;
	}


	public void setFilterCountry(Country filterCountry)
	{
		this.filterCountry = filterCountry;
	}


	public UploadFile getDocument()
	{
		return document;
	}


	public void setDocument(UploadFile document)
	{
		this.document = document;
	}

	public Date getFilterCreateDateFrom()
	{
		return filterCreateDateFrom;
	}

	public void setFilterCreateDateFrom(Date filterCreateDateFrom)
	{
		this.filterCreateDateFrom = filterCreateDateFrom;
	}

	public Date getFilterCreateDateTo()
	{
		return filterCreateDateTo;
	}

	public void setFilterCreateDateTo(Date filterCreateDateTo)
	{
		this.filterCreateDateTo = filterCreateDateTo;
	}

	public Date getFilterUpdateDateFrom()
	{
		return filterUpdateDateFrom;
	}

	public void setFilterUpdateDateFrom(Date filterUpdateDateFrom)
	{
		this.filterUpdateDateFrom = filterUpdateDateFrom;
	}

	public Date getFilterUpdateDateTo()
	{
		return filterUpdateDateTo;
	}

	public void setFilterUpdateDateTo(Date filterUpdateDateTo)
	{
		this.filterUpdateDateTo = filterUpdateDateTo;
	}

	public Boolean getFilterUpdateDateNotInInterval()
	{
		return filterUpdateDateNotInInterval;
	}

	public void setFilterUpdateDateNotInInterval(
			Boolean filterUpdateDateNotInInterval)
	{
		this.filterUpdateDateNotInInterval = filterUpdateDateNotInInterval;
	}

	public String getFilterSubstring()
	{
		return filterSubstring;
	}

	public void setFilterSubstring(String filterSubstring)
	{
		this.filterSubstring = filterSubstring;
	}


}
