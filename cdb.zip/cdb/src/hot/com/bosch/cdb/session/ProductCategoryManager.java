package com.bosch.cdb.session;

import java.io.IOException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.web.RequestParameter;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.log.Log;

import com.bosch.cdb.UploadFile;
import com.bosch.cdb.entity.Document;
import com.bosch.cdb.entity.ProductType;
import com.bosch.cdb.entity.ProductCategory;

/**
 * Business logic for management of product categories.
 * @author ago8fe
*/
@Name("productCategoryManager")
@Scope(ScopeType.CONVERSATION)
public class ProductCategoryManager 
{
	@Logger Log log;
	@In EntityManager entityManager;
	@In FacesMessages facesMessages;
	
	@RequestParameter(value="id") Long id;
	
	@In(create=true) DocumentManager documentManager;

	@In(required=false)
	@Out(required=false)
	private ProductCategory productCategory;

	@Out(required=false)
	private List<ProductCategory> productCategoryList;

	private ProductType filterProductType;

	private UploadFile typePlateDoc = new UploadFile();

	private void load()
	{
		if (null == id)
		{
			return;
		}
		productCategory = (ProductCategory) entityManager.find(ProductCategory.class, id);
		if (null == productCategory)
		{
			facesMessages.addFromResourceBundle(Severity.WARN, "productCategoryUnknown", id );
		}
	}
	
	@Factory(value="productCategoryList")
	@SuppressWarnings("unchecked")
	public void queryProductCategoryList()
	{
		String filterExpression = "";
		if (null != filterProductType)
		{
			filterExpression = " where x.productType = :filterProductType "; 
		}
		
		Query query = entityManager.createQuery("select x from ProductCategory x " + filterExpression + " order by x.name");
		
		if (null != filterProductType)
		{
			query.setParameter("filterProductType", filterProductType);
		}
		
		productCategoryList = query.getResultList();
	}
	
	public void deleteTypePlateDoc()
	{
		if (null == productCategory || null == productCategory.getTypePlateDoc()) return;
		Document document = productCategory.getTypePlateDoc();
		entityManager.remove(document);

		productCategory.setTypePlateDoc(null);
		entityManager.flush();
	}

	
	public void createProductCategory()
	{
		load();
		productCategory = new ProductCategory();
		productCategory.setEditMode(true);
	}

	public void viewProductCategory()
	{
		load();
		productCategory.setEditMode(false);
	}

	public void editProductCategory()
	{
		load();
		productCategory.setEditMode(true);
	}
	private void createDocuments() throws IOException
	{
		if (!typePlateDoc.isEmpty())
		{
			Document document = new Document(productCategory.getPrefixedId(), typePlateDoc);
			productCategory.setTypePlateDoc(document);
		}
	}

	public void saveProductCategory() throws IOException
	{
		// save previously persisted
		if (null != productCategory.getId())
		{
			createDocuments();
			facesMessages.addFromResourceBundle(Severity.INFO, "productCategorySaved", productCategory.getId());
		}
		else
		{
			entityManager.persist(productCategory);
			createDocuments();
			if (null != productCategoryList)
			{
				productCategoryList.add(productCategory);
			}
			facesMessages.addFromResourceBundle(Severity.INFO, "productCategoryCreated", productCategory.getId());
		}
		entityManager.flush();
	}
	
	public void deleteProductCategory()
	{
		load();
		
		if (null == productCategory) return;
		
		entityManager.remove(productCategory);
		
		try
		{
			entityManager.flush();
		}
		catch (RuntimeException e)
		{
			facesMessages.addFromResourceBundle(Severity.INFO, "cantDeleteObject", productCategory.getId());
			return;
		}

		if (null != productCategoryList)
		{
			productCategoryList.remove(productCategory);
		}
		
		facesMessages.addFromResourceBundle(Severity.INFO, "productCategoryDeleted", productCategory.getId());
		productCategory = null;

	}

	public void resetFilters()
	{
		setFilterProductType(null);
	}

	public void viewProductCategoryList()
	{
		resetFilters();
		queryProductCategoryList();
	}
	
	public void viewProductCategoryListResetFilters()
	{
		resetFilters();
		queryProductCategoryList();
	}

	public ProductType getFilterProductType()
	{
		return filterProductType;
	}

	public void setFilterProductType(ProductType filterProductType)
	{
		this.filterProductType = filterProductType;
	}

	public UploadFile getTypePlateDoc()
	{
		return typePlateDoc;
	}

	public void setTypePlateDoc(UploadFile typePlateDoc)
	{
		this.typePlateDoc = typePlateDoc;
	}


}
