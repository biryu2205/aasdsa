package com.bosch.cdb.session;

import java.io.IOException;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.web.RequestParameter;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.log.Log;

import com.bosch.cdb.UploadFile;
import com.bosch.cdb.entity.Brand;
import com.bosch.cdb.entity.Certificate;
import com.bosch.cdb.entity.Country;
import com.bosch.cdb.entity.Document;
import com.bosch.cdb.entity.Product;
import com.bosch.cdb.entity.ProductCategory;
import com.bosch.cdb.entity.Regulation;
import com.bosch.cdb.report.PdfCreator;
import com.bosch.commons.security.CustomIdentity;
import com.lowagie.text.DocumentException;

/**
 * Business logic for management of certificates.
 * @author ago8fe
*/
@Name("certificateManager")
@Scope(ScopeType.CONVERSATION)
public class CertificateManager 
{
	@Logger Log log;
	@In EntityManager entityManager;
	@In FacesMessages facesMessages;

    @In CustomIdentity identity;
	
    @In(create=true) ProductManager productManager;
    @In(create=true) RegulationManager regulationManager;
    @In(create=true) ProductCategoryManager productCategoryManager;
    @In(create=true) PdfCreator pdfCreator;
    @In(create=true) DocumentManager documentManager;

	@RequestParameter(value="id") Long id;
	@RequestParameter(value="documentId") Long documentId;
	
	@In(required=false)
	@Out(required=false)
	private Certificate certificate;

	@In(required=false)
	@Out(required=false)
	private List<Certificate> certificateList;

	private ProductCategory filterProductCategory;
	
	private Brand filterBrand;
	
	private String filterProductName;
	private String filterCertificateNumber;
	private String filterTTNR;

	private Product filterProduct;
	
	private Country filterCountry;

	private UploadFile certDoc = new UploadFile();
	private UploadFile certEupDirectiveDoc = new UploadFile();
	private UploadFile certOtherDoc = new UploadFile();
	private UploadFile certConfDeclUplDoc = new UploadFile();
	

	private void load()
	{
		System.out.println("load the certificate id:"+id);
		if (null == id)
		{
			return;
		}
		certificate = (Certificate) entityManager.find(Certificate.class, id);
		if (null == certificate)
		{
			facesMessages.addFromResourceBundle(Severity.WARN, "certificateUnknown", id );
		}
		else
		{
			log.debug("loaded id:"+certificate.getProduct().getName());
		}
	}
	
	public void print() throws IOException, DocumentException
	{
		load();
		pdfCreator.print(certificate);
	}

	public void resetFilters()
	{
		setFilterBrand(null);
		setFilterCountry(null);
		setFilterProduct(null);
		setFilterProductCategory(null);
		setFilterProductName(null);
		setFilterCertificateNumber(null);
		setFilterTTNR(null);
	}
	
	public void viewCertificateListResetFilters()
	{

		resetFilters();
		viewCertificateList();
	}

	public void viewCertificateList()
	{
		productCategoryManager.resetFilters();
		productCategoryManager.queryProductCategoryList();
		
		productManager.resetFilters();
		productManager.queryProductList();

		queryCertificateList();
	}

	@Factory(value="expiryWarningList")
	@SuppressWarnings("unchecked")
	public List<Certificate> loadExpiryWarningList()
	{
		String filterExpression = " and (:user member of x.expiryWarningRecipientList)";
		Query query = entityManager.createQuery("select x from Certificate x where x.expiryWarning < CURRENT_DATE " + filterExpression + " order by x.certificateNumber");
		query.setParameter("user", identity.getUser());
		return query.getResultList(); 
	}
	
	@Factory(value="certificateList")
	@SuppressWarnings("unchecked")
	public void queryCertificateList()
	{
		// update product selection list
		if (null != filterProductCategory || null != filterBrand)
		{
			productManager.setFilterProductCategory(filterProductCategory);
			productManager.setFilterBrand(filterBrand);
			productManager.queryProductList();
		}
		
		//
		String filterExpression = " where 0=0 ";
		
		if (null != filterBrand)
		{
			filterExpression += " and :filterBrand member of x.product.brandList ";
		}

		if (null != filterProductCategory)
		{
			filterExpression += " and :filterProductCategory = x.product.productCategory ";
		}

		if (null != filterProduct)
		{
			filterExpression += " and :filterProduct = x.product ";
		}
		String filterProductNamePattern = null;
		if (null != filterProductName && !"".equals(filterProductName.trim()))
		{
			filterProductNamePattern = "%" + filterProductName.toLowerCase() + "%";
			filterExpression += " and LOWER(x.product.name) like :filterProductNamePattern ";
		}
		
		String filterTTNRPattern = null;
		log.info(filterTTNR);
		if(null != filterTTNR && !"".equals(filterTTNR.trim()))
		{
			filterTTNRPattern = "%" + filterTTNR.toLowerCase() + "%";
			filterExpression += " and LOWER(x.ttnr) like :filterTTNRPattern ";
		}
		
		String filterCertificateNumberPattern = null;
		if(null != filterCertificateNumber  && !"".equals(filterCertificateNumber.trim()))
		{
			filterCertificateNumberPattern = "%" + filterCertificateNumber.toLowerCase() + "%";
			filterExpression += " and LOWER(x.certificateNumber) like :filterCertificateNumberPattern ";
		}

		Query query = entityManager.createQuery("select x from Certificate x " + filterExpression + " order by x.certificateNumber");

		if (null != filterBrand)
		{
			query.setParameter("filterBrand", filterBrand);
		}
		if (null != filterProductCategory)
		{
			query.setParameter("filterProductCategory", filterProductCategory);
		}
		if (null != filterProduct)
		{
			query.setParameter("filterProduct", filterProduct);
		}
		if (null != filterProductNamePattern)
		{
			query.setParameter("filterProductNamePattern", filterProductNamePattern);
		}
		if(null != filterTTNRPattern)
		{
			query.setParameter("filterTTNRPattern", filterTTNRPattern);
		}
		if(null != filterCertificateNumberPattern)
		{
			query.setParameter("filterCertificateNumberPattern", filterCertificateNumberPattern);
		}
		certificateList = query.getResultList();
		
		//
		// remove certificates which have no regulation for the specified country
		//
		
		if (null != filterCountry)
		{
			for (Iterator<Certificate> certIter = certificateList.iterator(); certIter.hasNext();)
			{
				boolean showCert = false;
				Certificate certificate = certIter.next();
				List<Regulation> regulationList = certificate.getRegulationList();
				if (null != regulationList  && !regulationList.isEmpty())
				{
					for (Iterator<Regulation> regulationIter = regulationList.iterator(); regulationIter.hasNext();)
					{
						Regulation regulation = regulationIter.next();
						List<Country> countryList = regulation.getCountryList();
						if (null != countryList && !countryList.isEmpty())
						{
							if (countryList.contains(filterCountry))
							{
								showCert=true;
							}
						}
						else
						{
							showCert=true;
						}
					}
				}
				else
				{
					showCert = true;
				}
				if (!showCert)
				{
					certIter.remove();
				}
			}
		}
		
	}
	
	public void createCertificate()
	{
		certificate = new Certificate();
		certificate.setCreateDate(new Date());
		certificate.setUpdateDate(new Date());
		certificate.setCreateUser(identity.getUser());
		certificate.setUpdateUser(identity.getUser());
		editCertificate();
		regulationManager.queryRegulationListUsingRegulationTypes();
	}

	public void viewCertificate()
	{
		load();
		certificate.setEditMode(false);
	}

	public void editCertificate()
	{
		load();
		productManager.queryAllProducts();
		productCategoryManager.queryProductCategoryList();
		certificate.setEditMode(true);
	}

	public void saveCertificate() throws IOException
	{
		// save previously persisted
		if((certificate.getEmailNotification() != null && certificate.getEmailNotification().booleanValue()) 
				&& certificate.getExpiryWarning() == null)
		{
			facesMessages.addFromResourceBundle(Severity.ERROR, "expiryWarningNotNull");
			return;
		}
		if (null != certificate.getId())
		{
			certificate.setUpdateDate(new Date());
			certificate.setUpdateUser(identity.getUser());
			createDocuments();
			facesMessages.addFromResourceBundle(Severity.INFO, "certificateSaved", certificate.getId());
		}
		else
		{
			entityManager.persist(certificate);
			createDocuments();
			if (null != certificateList)
			{
				certificateList.add(certificate);
			}
			facesMessages.addFromResourceBundle(Severity.INFO, "certificateCreated", certificate.getId());
		}

		entityManager.flush();
	}
	
	private void createDocuments() throws IOException
	{
		if (!certDoc.isEmpty())
		{
			Document document = new Document(certificate.getPrefixedId(), certDoc);
			certificate.getCertDocList().add(document);
		}
		if (!certOtherDoc.isEmpty())
		{
			Document document = new Document(certificate.getPrefixedId(), certOtherDoc);
			certificate.getCertOtherDocList().add(document);
		}
		if (!certConfDeclUplDoc.isEmpty())
		{
			Document document = new Document(certificate.getPrefixedId(), certConfDeclUplDoc);
			certificate.getConfDeclUplDocList().add(document);
		}
		if (!certEupDirectiveDoc.isEmpty())
		{
			Document document = new Document(certificate.getPrefixedId(), certEupDirectiveDoc);
			certificate.getCertEupDirectiveDocList().add(document);
		}
	}

	public void deleteCertDoc()
	{
		if (null == certificate || null == certificate.getCertDocList()) return;
		Document document = documentManager.getDocument(documentId);
		if (null != document)
		{
			certificate.getCertDocList().remove(document);
			entityManager.flush();
		}
		
	}

	public void deleteCertEupDirectiveDoc()
	{
		if (null == certificate || null == certificate.getCertEupDirectiveDocList()) return;
		Document document = documentManager.getDocument(documentId);
		entityManager.remove(document);
		if (null != document)
		{
			certificate.getCertEupDirectiveDocList().remove(document);
			entityManager.flush();
		}
	}
	
	public void deleteCertOtherDoc()
	{
		if (null == certificate || null == certificate.getCertOtherDocList()) return;
		Document document = documentManager.getDocument(documentId);
		entityManager.remove(document);
		if (null != document)
		{
			certificate.getCertOtherDocList().remove(document);
			entityManager.flush();
		}
	}
	
	public void deleteConfDeclUplDoc()
	{
		if (null == certificate || null == certificate.getConfDeclUplDocList()) return;
		Document document = documentManager.getDocument(documentId);
		entityManager.remove(document);
		if (null != document)
		{
			certificate.getConfDeclUplDocList().remove(document);
			entityManager.flush();
		}
	}

	public void deleteCertificate()
	{
		load();
		
		if (null == certificate) return;
		
		entityManager.remove(certificate);
		
		try
		{
			entityManager.flush();
		}
		catch (RuntimeException e)
		{
			facesMessages.addFromResourceBundle(Severity.INFO, "cantDeleteObject", certificate.getId());
			return;
		}
		
		if (null != certificateList)
		{
			certificateList.remove(certificate);
		}
		
		facesMessages.addFromResourceBundle(Severity.INFO, "certificateDeleted", certificate.getId());
		certificate = null;
	}
	
	public ProductCategory getFilterProductCategory()
	{
		return filterProductCategory;
	}

	public void setFilterProductCategory(ProductCategory filterProductCategory)
	{
		this.filterProductCategory = filterProductCategory;
	}

	public Brand getFilterBrand()
	{
		return filterBrand;
	}

	public void setFilterBrand(Brand filterBrand)
	{
		this.filterBrand = filterBrand;
	}

	public String getFilterProductName()
	{
		return filterProductName;
	}

	public void setFilterProductName(String filterProductName)
	{
		this.filterProductName = filterProductName;
	}

	public Product getFilterProduct()
	{
		return filterProduct;
	}

	public void setFilterProduct(Product filterProduct)
	{
		this.filterProduct = filterProduct;
	}

	public Country getFilterCountry()
	{
		return filterCountry;
	}

	public void setFilterCountry(Country filterCountry)
	{
		this.filterCountry = filterCountry;
	}
	
	public String getFilterCertificateNumber() {
		return filterCertificateNumber;
	}

	public void setFilterCertificateNumber(String filterCertificateNumber) {
		this.filterCertificateNumber = filterCertificateNumber;
	}

	public String getFilterTTNR() {
		return filterTTNR;
	}

	public void setFilterTTNR(String filterTTNR) {
		this.filterTTNR = filterTTNR;
	}

	public UploadFile getCertDoc()
	{
		return certDoc;
	}

	public void setCertDoc(UploadFile certDoc)
	{
		this.certDoc = certDoc;
	}

	public UploadFile getCertOtherDoc()
	{
		return certOtherDoc;
	}

	public void setCertOtherDoc(UploadFile certOtherDoc)
	{
		this.certOtherDoc = certOtherDoc;
	}

	public UploadFile getCertConfDeclUplDoc()
	{
		return certConfDeclUplDoc;
	}

	public void setCertConfDeclUplDoc(UploadFile certConfDeclUplDoc)
	{
		this.certConfDeclUplDoc = certConfDeclUplDoc;
	}

	public UploadFile getCertEupDirectiveDoc()
	{
		return certEupDirectiveDoc;
	}

	public void setCertEupDirectiveDoc(UploadFile certEupDirectiveDoc)
	{
		this.certEupDirectiveDoc = certEupDirectiveDoc;
	}

	public void cloneCertificate() throws IOException
	{
		try {
			Certificate newCertificate = new Certificate();
			newCertificate.cloneCertificate(certificate);
			newCertificate.setCreateDate(new Date());
			newCertificate.setUpdateDate(new Date());
			newCertificate.setCreateUser(identity.getUser());
			newCertificate.setUpdateUser(identity.getUser());
			newCertificate.setEditMode(true);
			regulationManager.queryRegulationListUsingRegulationTypes();
			entityManager.persist(newCertificate);
			newCertificate.cloneCertificatesDocuments(certificate);
			entityManager.persist(newCertificate);
			entityManager.flush();
			facesMessages.addFromResourceBundle(Severity.INFO, "certificateCopied", certificate.getId(),newCertificate.getId());
			System.out.println(newCertificate.getId());
			certificate = null;
			certificate = newCertificate;
			id = certificate.getId();
			load();
			}
			catch(Exception e) {
			System.out.println("EXCEPTION CAUGHT: " + e.getMessage());
			}
	//	saveCertificate();
		
	}
}
