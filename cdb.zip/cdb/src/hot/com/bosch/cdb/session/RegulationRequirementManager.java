package com.bosch.cdb.session;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.web.RequestParameter;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.log.Log;

import com.bosch.cdb.UploadFile;
import com.bosch.cdb.entity.Country;
import com.bosch.cdb.entity.Document;
import com.bosch.cdb.entity.ProductCategory;
import com.bosch.cdb.entity.Regulation;
import com.bosch.cdb.entity.RegulationRequirement;
import com.bosch.cdb.entity.RegulationType;
import com.bosch.cdb.report.PdfCreator;
import com.bosch.commons.security.CustomIdentity;
import com.lowagie.text.DocumentException;

/**
 * Business logic for management of standards.
 * @author ago8fe
*/
@Name("regulationRequirementManager")
@Scope(ScopeType.CONVERSATION)
public class RegulationRequirementManager
{
	@Logger Log log;
	@In EntityManager entityManager;
	@In FacesMessages facesMessages;
    @In CustomIdentity identity;

    @In(create=true) RegulationManager regulationManager;
	@In(create=true) ProductCategoryManager productCategoryManager;
	@In(create=true) DocumentManager documentManager;
    @In(create=true) PdfCreator pdfCreator;

	@RequestParameter(value="id") Long id;
	@RequestParameter(value="documentId") Long documentId;
    
	@In(required=false)
	@Out(required=false)
	private RegulationRequirement regulationRequirement;

	private List<RegulationRequirement> regulationRequirementList;

	private UploadFile document = new UploadFile();
	
	private ProductCategory filterProductCategory;
	private Regulation filterRegulation;
	private Country filterCountry;
	private RegulationType filterRegulationType;
	
	private Date filterCreateDateFrom;
	private Date filterCreateDateTo;
	private Date filterUpdateDateFrom;
	private Date filterUpdateDateTo;
	private Boolean filterUpdateDateNotInInterval;
	private String filterSubstring;

	private void load() 
	{
		if (null == id)
		{
			return;
		}
		regulationRequirement = (RegulationRequirement) entityManager.find(RegulationRequirement.class, id);
		if (null == regulationRequirement)
		{
			facesMessages.addFromResourceBundle(Severity.WARN, "regulationRequirementUnknown", id );
		}
	}

	public void print() throws IOException, DocumentException
	{
		load();
		pdfCreator.print(regulationRequirement);
	}
	
	public void deleteDocument()
	{
		Document document = documentManager.getDocument(documentId);
		if (null != document && null != regulationRequirement.getDocumentList())
		{
			regulationRequirement.getDocumentList().remove(document);
			entityManager.flush();
		}
	}

	private void createDocuments() throws IOException
	{
		
		if (!document.isEmpty())
		{
			Document tmpDoc = new Document(regulationRequirement.getPrefixedId(), document);
			regulationRequirement.getDocumentList().add(tmpDoc);
		}
	}

	@SuppressWarnings("unchecked")
	public void queryRegulationRequirementList()
	{
		if (null != filterRegulationType || null != filterCountry)
		{
			regulationManager.setFilterRegulationType(filterRegulationType);
			regulationManager.setFilterCountry(filterCountry);
			regulationManager.queryRegulationList();
		}
		String filterExpression = " where 0=0 ";
		
		
		if (null != filterCountry)
		{
			filterExpression += " and :filterCountry member of x.regulation.countryList ";
		}

		if (null != filterProductCategory)
		{
			filterExpression += " and :filterProductCategory member of x.productCategoryList ";
		}
		if (null != filterRegulation)
		{
			filterExpression += " and :filterRegulation = x.regulation ";
		}
		if (null != filterRegulationType)
		{
			filterExpression += " and :filterRegulationType = x.regulation.regulationType ";
		}

		if (null != filterCreateDateFrom)
		{
			filterExpression += " and :filterCreateDateFrom <= x.createDate ";
		}
		if (null != filterCreateDateTo)
		{
			filterExpression += " and :filterCreateDateTo >= x.createDate ";
		}
		
		if (null == filterUpdateDateNotInInterval || filterUpdateDateNotInInterval.equals(Boolean.FALSE))
		{
			if (null != filterUpdateDateFrom)
			{
				filterExpression += " and :filterUpdateDateFrom <= x.updateDate ";
			}
			if (null != filterUpdateDateTo)
			{
				filterExpression += " and :filterUpdateDateTo >= x.updateDate ";
			}
		}
		else
		{
			if(null != filterUpdateDateFrom || null != filterUpdateDateTo)
			{
				filterExpression += " and ( ";
				
				if (null != filterUpdateDateFrom)
				{
					filterExpression += " :filterUpdateDateFrom > x.updateDate ";
				}
				
				if (null != filterUpdateDateFrom && null != filterUpdateDateTo)
				{
					filterExpression += " or ";
				}
				
				if (null != filterUpdateDateTo)
				{
					filterExpression += " :filterUpdateDateTo < x.updateDate ";
				}			
				
				filterExpression += " or x.updateDate = null ) ";
			}
		}

		String filterSubstringPattern = null;
		if (null != filterSubstring && !"".equals(filterSubstring.trim()))
		{
			filterSubstringPattern = "%" + filterSubstring.toLowerCase() + "%";
			filterExpression += " and ( exists (select c from Country c where LOWER(c.code) like :filterSubstringPattern and c member of x.regulation.countryList) " +
					"or LOWER(x.remark) like :filterSubstringPattern) ";
		}
			
		Query query = entityManager.createQuery("select x from RegulationRequirement x " + filterExpression);
		
		if (null != filterCountry)
		{
			query.setParameter("filterCountry", filterCountry);
		}
		if (null != filterProductCategory)
		{
			query.setParameter("filterProductCategory", filterProductCategory);
		}
		if (null != filterRegulation)
		{
			query.setParameter("filterRegulation", filterRegulation);
		}
		if (null != filterRegulationType)
		{
			query.setParameter("filterRegulationType", filterRegulationType);
		}

		if (null != filterCreateDateFrom)
		{
			query.setParameter("filterCreateDateFrom", filterCreateDateFrom);
		}
		if (null != filterCreateDateTo)
		{
			filterCreateDateTo.setHours(23);
			filterCreateDateTo.setMinutes(59);
			query.setParameter("filterCreateDateTo", filterCreateDateTo);
		}

		if (null != filterUpdateDateFrom)
		{
			query.setParameter("filterUpdateDateFrom", filterUpdateDateFrom);
		}
		if (null != filterUpdateDateTo)
		{
			filterUpdateDateTo.setHours(23);
			filterUpdateDateTo.setMinutes(59);
			query.setParameter("filterUpdateDateTo", filterUpdateDateTo);
		}
		
		if (null != filterSubstringPattern)
		{
			query.setParameter("filterSubstringPattern", filterSubstringPattern);
		}

		regulationRequirementList = query.getResultList();
		
	}
	
	public void createRegulationRequirement()
	{
		regulationRequirement = new RegulationRequirement();
		regulationRequirement.setCreateDate(new Date());
		regulationRequirement.setUpdateDate(new Date());
		regulationRequirement.setCreateUser(identity.getUser());
		regulationRequirement.setUpdateUser(identity.getUser());
		editRegulationRequirement();
	}

	public void editRegulationRequirement()
	{
		load();
		if (null == regulationRequirement)
		{
			return;
		}
		regulationRequirement.setEditMode(true);
	}

	public void viewRegulationRequirement()
	{
		load();
		regulationRequirement.setEditMode(false);
	}

	public void saveRegulationRequirement() throws IOException
	{
		// save previously persisted
		if (null != regulationRequirement.getId())
		{
			regulationRequirement.setUpdateDate(new Date());
			regulationRequirement.setUpdateUser(identity.getUser());
			entityManager.persist(regulationRequirement);
			createDocuments();
			facesMessages.addFromResourceBundle(Severity.INFO, "regulationRequirementSaved", regulationRequirement.getId());
		}
		else
		{
			entityManager.persist(regulationRequirement);
			createDocuments();
			if (null != regulationRequirementList)
			{
				regulationRequirementList.add(regulationRequirement);
			}
			facesMessages.addFromResourceBundle(Severity.INFO, "regulationRequirementCreated", regulationRequirement.getId());
		}
		entityManager.flush();
	}
	
	public void deleteRegulationRequirement()
	{
		load();
		
		if (null == regulationRequirement) return;
		
		entityManager.remove(regulationRequirement);

		try
		{
			entityManager.flush();
		}
		catch (RuntimeException e)
		{
			facesMessages.addFromResourceBundle(Severity.INFO, "cantDeleteObject", regulationRequirement.getId());
			return;
		}

		if (null != regulationRequirementList)
		{
			regulationRequirementList.remove(regulationRequirement);
		}
		
		facesMessages.addFromResourceBundle(Severity.INFO, "regulationRequirementDeleted", regulationRequirement.getId());
		
		regulationRequirement = null;
	}
	
	public void resetFilters()
	{
		setFilterCountry(null);
		setFilterProductCategory(null);
		setFilterRegulation(null);
		setFilterRegulationType(null);
		setFilterCreateDateFrom(null);
		setFilterCreateDateTo(null);
		setFilterUpdateDateFrom(null);
		setFilterUpdateDateTo(null);
		setFilterUpdateDateNotInInterval(null);
		setFilterSubstring(null);
	}

	public void viewRegulationRequirementListResetFilters()
	{
		resetFilters();
		viewRegulationRequirementList();
	}
	
	public void viewRegulationRequirementList()
	{
		productCategoryManager.resetFilters();
		productCategoryManager.queryProductCategoryList();
		
		regulationManager.resetFilters();
		regulationManager.queryRegulationList();

		queryRegulationRequirementList();
	}

	public ProductCategory getFilterProductCategory()
	{
		return filterProductCategory;
	}

	public void setFilterProductCategory(ProductCategory filterProductCategory)
	{
		this.filterProductCategory = filterProductCategory;
	}

	public Regulation getFilterRegulation()
	{
		return filterRegulation;
	}

	public void setFilterRegulation(Regulation filterRegulation)
	{
		this.filterRegulation = filterRegulation;
	}

	public Country getFilterCountry()
	{
		return filterCountry;
	}

	public void setFilterCountry(Country filterCountry)
	{
		this.filterCountry = filterCountry;
	}

	public RegulationType getFilterRegulationType()
	{
		return filterRegulationType;
	}

	public void setFilterRegulationType(RegulationType filterRegulationType)
	{
		this.filterRegulationType = filterRegulationType;
	}

	public UploadFile getDocument() {
		return document;
	}

	public void setDocument(UploadFile document) {
		this.document = document;
	}

	public List<RegulationRequirement> getRegulationRequirementList()
	{
		return regulationRequirementList;
	}

	public Date getFilterCreateDateFrom()
	{
		return filterCreateDateFrom;
	}

	public void setFilterCreateDateFrom(Date filterCreateDateFrom)
	{
		this.filterCreateDateFrom = filterCreateDateFrom;
	}

	public Date getFilterCreateDateTo()
	{
		return filterCreateDateTo;
	}

	public void setFilterCreateDateTo(Date filterCreateDateTo)
	{
		this.filterCreateDateTo = filterCreateDateTo;
	}

	public Date getFilterUpdateDateFrom()
	{
		return filterUpdateDateFrom;
	}

	public void setFilterUpdateDateFrom(Date filterUpdateDateFrom)
	{
		this.filterUpdateDateFrom = filterUpdateDateFrom;
	}

	public Date getFilterUpdateDateTo()
	{
		return filterUpdateDateTo;
	}

	public void setFilterUpdateDateTo(Date filterUpdateDateTo)
	{
		this.filterUpdateDateTo = filterUpdateDateTo;
	}

	public Boolean getFilterUpdateDateNotInInterval()
	{
		return filterUpdateDateNotInInterval;
	}

	public void setFilterUpdateDateNotInInterval(
			Boolean filterUpdateDateNotInInterval)
	{
		this.filterUpdateDateNotInInterval = filterUpdateDateNotInInterval;
	}

	public String getFilterSubstring()
	{
		return filterSubstring;
	}

	public void setFilterSubstring(String filterSubstring)
	{
		this.filterSubstring = filterSubstring;
	}

}
