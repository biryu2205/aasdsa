package com.bosch.cdb.session;

import java.util.List;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.web.RequestParameter;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.log.Log;

import com.bosch.cdb.entity.InformationType;


/**
 * Business logic for management of standards.
 * @author wlm1fe
*/
@Name("informationTypeManager")
@Scope(ScopeType.CONVERSATION)
public class InformationTypeManager
{
	@Logger Log log;
	@In EntityManager entityManager;
	@In FacesMessages facesMessages;

	@RequestParameter(value="id") Long id;
	
	@In(required=false)
	@Out(required=false)
	private InformationType informationType;

	@Out(required=false)
	private List<InformationType> informationTypeList;

	private void load()
	{
		if (null == id)
		{
			return;
		}
		informationType = (InformationType) entityManager.find(InformationType.class, id);
		if (null == informationType)
		{
			facesMessages.addFromResourceBundle(Severity.WARN, "informationTypeUnknown", id );
		}
	}
	
	@Factory(value="informationTypeList")
	@SuppressWarnings("unchecked")
	public void queryInformationTypeList()
	{
		informationTypeList = entityManager.createQuery("select x from InformationType x order by x.name").getResultList();
	}

	public void createInformationType()
	{
		informationType = new InformationType();
		informationType.setEditMode(true);
	}

	public void editInformationType()
	{
		load();
		informationType.setEditMode(true);
	}

	public void viewInformationType()
	{
		load();
		informationType.setEditMode(false);
	}

	public void saveInformationType()
	{
		// save previously persisted
		if (null != informationType.getId())
		{
			entityManager.persist(informationType);
			facesMessages.addFromResourceBundle(Severity.INFO, "informationTypeSaved", informationType.getId());
		}
		else
		{
			entityManager.persist(informationType);
			if (null != informationTypeList)
			{
				informationTypeList.add(informationType);
			}
			facesMessages.addFromResourceBundle(Severity.INFO, "informationTypeCreated", informationType.getId());
		}
		informationType = null;
		entityManager.flush();
	}
	
	public void deleteInformationType()
	{
		load();
		
		if (null == informationType) return;
		
		entityManager.remove(informationType);

		try
		{
			entityManager.flush();
		}
		catch (RuntimeException e)
		{
			facesMessages.addFromResourceBundle(Severity.INFO, "cantDeleteObject", informationType.getId());
			return;
		}

		if (null != informationTypeList)
		{
			informationTypeList.remove(informationType);
		}
		
		facesMessages.addFromResourceBundle(Severity.INFO, "informationTypeDeleted", informationType.getId());
		informationType = null;
	}
	
	public void viewInformationTypeList()
	{
		queryInformationTypeList();
	}

}
