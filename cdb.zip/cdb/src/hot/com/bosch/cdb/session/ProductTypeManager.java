package com.bosch.cdb.session;

import java.util.List;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Factory;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Out;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.web.RequestParameter;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.log.Log;

import com.bosch.cdb.entity.ProductType;

/**
 * Business logic for management of countries.
 * @author ago8fe
*/
@Name("productTypeManager")
@Scope(ScopeType.CONVERSATION)
public class ProductTypeManager 
{
	@Logger Log log;
	@In EntityManager entityManager;
	@In FacesMessages facesMessages;

	@RequestParameter(value="id") Long id;

	@In(required=false)
	@Out(required=false)
	private ProductType productType;

	@Out(required=false)
	private List<ProductType> productTypeList;

	private void load()
	{
		if (null == id)
		{
			return;
		}
		productType = (ProductType) entityManager.find(ProductType.class, id);
		if (null == productType)
		{
			facesMessages.addFromResourceBundle(Severity.WARN, "productTypeUnknown", id );
		}
	}

	@Factory(value="productTypeList")
	@SuppressWarnings("unchecked")
	public void queryProductTypeList()
	{
		productTypeList = entityManager.createQuery("select x from ProductType x order by x.name").getResultList();
	}

	public void viewProductTypeList()
	{
		queryProductTypeList();
	}
	
	public void createProductType()
	{
		productType = new ProductType();
		productType.setEditMode(true);
	}

	public void editProductType()
	{
		load();
		productType.setEditMode(true);
	}

	public void viewProductType()
	{
		load();
		productType.setEditMode(false);
	}

	public void saveProductType()
	{
		// save previously persisted
		if (null != productType.getId())
		{
			entityManager.persist(productType);
			facesMessages.addFromResourceBundle(Severity.INFO, "productTypeSaved", productType.getId());
		}
		else
		{
			entityManager.persist(productType);
			if (null != productTypeList)
			{
				productTypeList.add(productType);
			}
			facesMessages.addFromResourceBundle(Severity.INFO, "productTypeCreated", productType.getId());
		}
		productType = null;
		
		entityManager.flush();
	}
	
	public void deleteProductType()
	{
		load();
		
		if (null == productType) return;
		
		entityManager.remove(productType);
		
		try
		{
			entityManager.flush();
		}
		catch (RuntimeException e)
		{
			facesMessages.addFromResourceBundle(Severity.INFO, "cantDeleteObject", productType.getId());
			return;
		}

		if (null != productTypeList)
		{
			productTypeList.remove(productType);
		}
		
		facesMessages.addFromResourceBundle(Severity.INFO, "productTypeDeleted", productType.getId());
		
		productType = null;
	}
	
}
