package com.bosch.cdb.async;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.Transactional;
import org.jboss.seam.contexts.Contexts;
import org.jboss.seam.core.Events;
import org.jboss.seam.faces.Renderer;
import org.jboss.seam.log.Log;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobKey;

import com.bosch.cdb.common.SystemCustomizing;
import com.bosch.cdb.entity.Certificate;
import com.bosch.cdb.session.SystemConfigurationManager;
import com.bosch.cdb.utilities.Constants;
import com.bosch.commons.security.User;


@Name("emailScheduleProcessor")
@Scope(ScopeType.STATELESS)
public class EmailScheduleProcessor implements Job
{

	@Logger Log log;
	
	/**
	 * Inject a renderer to be able to render the email template
	 */
	@In Renderer renderer;
	@In EntityManager entityManager;
	@In private Events events;
	
	@In (create=true) SystemConfigurationManager systemConfigurationManager;
	/**
	 * saves the count of the roundtrips
	 */
	private String emailTemplate = null;

	@Transactional
	public void execute(JobExecutionContext context) throws JobExecutionException {
		log.info("execute");	
		JobKey jobKey = context.getJobDetail().getKey();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		Calendar lastProcessedDate = Calendar.getInstance(); // creates calendar
		String emailIntervall = "0";
		
		List<SystemCustomizing> systemCustomizingList =  getSystemConfigurationList();
		
		for(SystemCustomizing systemCustomizing: systemCustomizingList)
		{
			if(Constants.systemConfigLastProcessedEmailTime.equals(systemCustomizing.getKey()))
			{
				try {
					lastProcessedDate.setTime(sdf.parse(systemCustomizing.getValue()));
				} catch (ParseException e) {
					e.printStackTrace();
				} // sets calendar time/date
			}
			if(Constants.systemConfigEmailIntervall.equals(systemCustomizing.getKey()) && systemCustomizing.getValue() != null)
			{
				emailIntervall = systemCustomizing.getValue().trim();
			}
		}
		
		lastProcessedDate.add(Calendar.DATE,new Integer(emailIntervall));
		if(lastProcessedDate.after(Calendar.getInstance()))
		{
		  return;	
		}
		
		Query query = entityManager.createQuery("select distinct e from Certificate x, User e where e member of x.expiryWarningRecipientList and x.emailNotification = true and x.expiryWarning + 1 < current_date and e.mail is not null ");
		@SuppressWarnings("unchecked")
		List<User> userList = query.getResultList();
		log.debug("userList  :"+userList);
		if(userList == null)return;
		log.debug("size :"+userList.size());
		for (Iterator<User> iterator = userList.iterator(); iterator.hasNext();)
		{
			User user = iterator.next();
			ArrayList handledUser = new ArrayList<User>();
			handledUser.add(user);
			query = entityManager.createQuery("select x from Certificate x, User e where x.expiryWarning + 1 < current_date and x.emailNotification = true and e member of x.expiryWarningRecipientList and e.id = :userid");
			query.setParameter("userid",user.getId());
			@SuppressWarnings("unchecked")
			List<Certificate> certificateList = query.getResultList();
			if(certificateList ==  null || certificateList.size() == 0)continue;
			Contexts.getEventContext().set("certificateList",certificateList); // mailsender
			log.info("send Email to User: "+user.getMail());
			events.raiseEvent("com.bosch.cdb.certificate.notification",handledUser,null);
		
		}
		log.info("set LastProcessEmailDate");			
		 entityManager.joinTransaction();
		 query = entityManager.createNamedQuery("findSystemCustomizingByKey");
		 query.setParameter("key", Constants.systemConfigLastProcessedEmailTime);
		 SystemCustomizing sysconfi=(SystemCustomizing) query.getSingleResult();
                
        sysconfi.setValue((new SimpleDateFormat("yyyy/MM/dd")).format(Calendar.getInstance().getTime()));
        entityManager.flush();
        entityManager.close();
        		
		
	}	
		
	private List<SystemCustomizing> getSystemConfigurationList()
	{
		log.debug("schedule");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		Calendar lastProcessedDate = Calendar.getInstance(); // creates calendar
		String emailIntervall = "0";
		
		return entityManager.createQuery("select sys from SystemCustomizing sys").getResultList();
	}

}
