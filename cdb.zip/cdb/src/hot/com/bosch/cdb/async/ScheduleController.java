package com.bosch.cdb.async;



import java.util.Date;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.AutoCreate;
import org.jboss.seam.annotations.Create;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.Startup;
import org.jboss.seam.log.Log;
import org.quartz.DateBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.SimpleTrigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

import com.bosch.cdb.utilities.ApplicationEnvironment;

@Name("scheduleController")
@Scope(ScopeType.APPLICATION)
@Startup
@AutoCreate
public class ScheduleController
{
	
	@In(create=true) 
	ApplicationEnvironment applicationEnvironment;
	
	@In(create=true)
	private SeamJobFactory seamJobFactory;
	
	@Logger Log log;
		
	Scheduler sched = null;
	
	@Create
	public void asynchronEmail() throws Exception
	{
		
		 log.info("------- Initializing -------------------");    	
		//handle = graphicStatusBuildProcessor.doStatusBuild(new Date(), 1000*60L*60L*12L, cal.getTime());
				
	    if("true".equalsIgnoreCase(applicationEnvironment.getSendMail()))
		{
	    	if(sched ==  null) 
	    	{
	    		 
	    		sched = new StdSchedulerFactory().getScheduler();
	    		sched.setJobFactory(seamJobFactory);

		        log.info("------- Initialization Complete --------");

		        log.info("------- Scheduling Jobs ----------------");
	    	}
	    	
	        // jobs can be scheduled before sched.start() has been called
	        // job 1 will run every 1 hour org.quartz.JobDetail.JobDetail
	    	sched.startDelayed(40);  
	    	 Date startTime = DateBuilder.nextGivenMinuteDate(null, 1);
	    	JobDetail emailJob = JobBuilder.newJob(EmailScheduleProcessor.class)  
	                .withIdentity("emailJob", "emailGroup")  
	                .build(); 
	    	 SimpleTrigger trigger = TriggerBuilder.newTrigger()  
	    	            .withIdentity("emailTrigger", "emailGroup")  
	    	            .startAt(startTime)
	    	            .withSchedule(SimpleScheduleBuilder.simpleSchedule()  
	    	            .withIntervalInMinutes(60)
	    	            .repeatForever())  
	    	            .build();  
	    	
	    	 sched.scheduleJob(emailJob, trigger);  
	    		    	
	    	 /*Trigger trigger = TriggerBuilder
	    				.newTrigger()
	    				.withIdentity("dummyTriggerName", "group1")
	    				.withSchedule(
	    					CronScheduleBuilder.cronSchedule("0 6/2 * * * ?"))
	    				.build();
	     sched.scheduleJob(emailJob, trigger);
	   	sched.startDelayed(10);  */
	                   
		}
	    
	 }
	
	
}
