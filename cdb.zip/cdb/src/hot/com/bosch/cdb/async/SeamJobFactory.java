package com.bosch.cdb.async;


import org.jboss.seam.Component;
import org.jboss.seam.Seam;
import org.jboss.seam.annotations.Name;
import org.quartz.Job;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.spi.JobFactory;
import org.quartz.spi.TriggerFiredBundle;

@Name("seamJobFactory")
public class SeamJobFactory implements JobFactory {
	 
		   public Job newJob(TriggerFiredBundle bundle, Scheduler Scheduler) throws SchedulerException {
		 
		      final JobDetail jobDetail = bundle.getJobDetail();
		      final Class<? extends Job> jobClass = jobDetail.getJobClass();
		      try {
		         
		    	  
		         return (Job) Component.getInstance(EmailScheduleProcessor.class);
		      } catch (Exception e) {
		         throw new SchedulerException(
		               "Problem instantiating class '"
		                     + jobDetail.getJobClass().getName() + "'", e);
		      }
		   }
		   
		   		 
}
