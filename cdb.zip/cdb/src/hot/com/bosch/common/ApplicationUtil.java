package com.bosch.common;

import java.util.ArrayList;
import java.util.List;

import com.bosch.cdb.entity.Document;
import com.bosch.cdb.session.DocumentManager;

public class ApplicationUtil {

	public static List<Document> getListDocument(DocumentManager documentManager, List<Document> oldDocs) {
		List<Document> documents = oldDocs;
		List<Document> docExists = new ArrayList<Document>();
		if (documents != null && documents.size() > 0) {
			for (Document document : documents) {
				if (documentManager.checkFileExist(document))
					docExists.add(document);
			}
		}
		return docExists;
	}
	
}
