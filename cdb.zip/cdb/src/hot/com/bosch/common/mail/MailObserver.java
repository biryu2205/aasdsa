package com.bosch.common.mail;

import java.util.ArrayList;
import java.util.List;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.AutoCreate;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Install;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Observer;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.Startup;
import org.jboss.seam.contexts.Contexts;
import org.jboss.seam.core.Events;
import org.jboss.seam.faces.Renderer;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.international.StatusMessages;
import org.jboss.seam.log.Log;

import com.bosch.cdb.utilities.ApplicationEnvironment;
import com.bosch.commons.security.User;


@Name("mailObserver")
@Scope(ScopeType.APPLICATION)
public class MailObserver {

	@Logger 
	private Log log;

    @In 
    private StatusMessages statusMessages;	

    
    @In(create = true)
  	Renderer renderer;
			
	@In 
    private Events events;
	
	@In(create=true) 
	ApplicationEnvironment applicationEnvironment;

	public static final String SAMPLE_EVENT = "com.bosch.vwms.events.sampleMailEvent";
	
	private List<User> recipients = new ArrayList<User>();
	private List<User> ccRecipiens = new ArrayList<User>();
	
	@Observer("com.bosch.cdb.certificate.notification")
	synchronized public void catchCertificateNotificationEvent(List<User> _recipients, List<User> _ccRecipients){

		log.debug("MailObserver.catchCertificateNotificationEvent(List<User>),List<User>)");

		this.recipients = filter(_recipients);
		this.ccRecipiens = filter(_ccRecipients);
		
		sendMail("/emailTemplates/certificateExpiryReminder.xhtml");
		
	}
	
	private List<User> filter(List<User> users){

		ArrayList<User> filteredList = new ArrayList<User>();
		if(users == null) return filteredList;
		for (User user : users) {
			
			if (user.getMail() != null 
		    	&& user.getMail().length() >0
		    	) 
			{
				filteredList.add(user);
			}//end if
			
		}//end for
		
		return filteredList;
		
	}
		
    synchronized private void sendMail(String template){
    	log.info("MailObserver.sendMail(String template, List<String> recipients)");
    
		try{
			
			if("true".equalsIgnoreCase(applicationEnvironment.getSendMail()))
			{
				if(this.recipients.size() >0)
				{
				Contexts.getEventContext().set("recipients",this.recipients ); // recipients or remainingRecipients	
				Contexts.getEventContext().set("ccrecipients",this.ccRecipiens ); // ccrecipients 
				//wait(4000);
				
				renderer.render(template);
				log.info("sent Email to "+this.recipients.size() +"Users");
				}
			}
			else{
				statusMessages.addFromResourceBundle(Severity.INFO, "Cant send email, Emailserver is deactivated");
			}
			
		}catch(Exception e){
			
			log.error("Error while mailing "+e);
			e.printStackTrace();
		}	    	
    }
 

}
