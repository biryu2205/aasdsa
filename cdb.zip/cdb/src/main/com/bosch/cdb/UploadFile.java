package com.bosch.cdb;

public class UploadFile
{
	private String fileName;

	private String contentType;
	
	private int fileSize = 0;
	
	private byte[] data = new byte[0];

	public String getFileNameWithoutPath()
	{
		String fileNameWithoutPath = fileName;
		if (null != fileNameWithoutPath && fileNameWithoutPath.length()>0)
		{
			int lastIndex = fileNameWithoutPath.lastIndexOf("\\");
			if (lastIndex != -1 && lastIndex < fileNameWithoutPath.length()-1)
			{
				fileNameWithoutPath = fileNameWithoutPath.substring(lastIndex+1);
			}
		}
		return fileNameWithoutPath;
	}
	
	public boolean isEmpty()
	{
		if (null != data && data.length > 0 && fileSize >0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
	public void clean()
	{
		fileName = null;
		contentType = null;
		fileSize = 0;
		data = null;
	}
	
	public String getFileName()
	{
		return fileName;
	}

	public void setFileName(String fileName)
	{
		this.fileName = fileName;
	}

	public String getContentType()
	{
		return contentType;
	}

	public void setContentType(String contentType)
	{
		this.contentType = contentType;
	}

	public int getFileSize()
	{
		return fileSize;
	}

	public void setFileSize(int fileSize)
	{
		this.fileSize = fileSize;
	}

	public byte[] getData()
	{
		return data;
	}

	public void setData(byte[] data)
	{
		this.data = data;
	}
	
	
}
