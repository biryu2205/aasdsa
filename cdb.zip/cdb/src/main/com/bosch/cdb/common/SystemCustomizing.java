package com.bosch.cdb.common;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "cdb_systemCustomizing")
@NamedQuery(name="findSystemCustomizingByKey", query="SELECT sc FROM SystemCustomizing sc WHERE sc.key LIKE (:key)")
public class SystemCustomizing implements Serializable
{
	  
		/**
	 * 
	 */
	private static final long serialVersionUID = 8441027000236231608L;
	private Long id;
	private String key;
	
	@Column(name="type")
	private String type;
	
	@Column(name = "values")
	private String value;
	
	@Id
    public Long getId()
    {
        return id;
    }

    public void setId(final Long id)
    {
        this.id = id;
    }

    public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	    
}
