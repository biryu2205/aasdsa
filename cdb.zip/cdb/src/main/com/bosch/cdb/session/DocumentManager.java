package com.bosch.cdb.session;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;

import javax.persistence.EntityManager;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.web.RequestParameter;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.log.Log;

import com.bosch.cdb.entity.Document;

/**
 * Business logic for management of documents.
 * @author ago8fe
 *
 */
@Name("documentManager")
@Scope(ScopeType.CONVERSATION)
public class DocumentManager implements Serializable
{
	@Logger Log log;
	@In EntityManager entityManager;
	@In FacesMessages facesMessages;
	
	@In(create=true) 
	FileManager fileManager;
	
	@RequestParameter
	private Long idParameter;

	public void saveFile(Document document) throws IOException
	{
		if (null == document) return;
		
		if (null != document.getFileName() && null != document.getData() && document.getData().length > 0)
		{
			fileManager.saveFile(document.getFolder(), document.getId().toString(), document.getData());
			document.setData(null);
		}		
	}

	public void downloadFile() throws FileNotFoundException, IOException 
	{
		Document document = entityManager.find(Document.class, idParameter);
		if (null == document)
		{
			facesMessages.addFromResourceBundle(Severity.WARN, "documentNotFound", idParameter );
			return;
		}
		String displayFileName = document.getFileName();
		fileManager.downloadFile(document.getFolder(), document.getId().toString(), document.getContentType() , displayFileName);
	}
	
	public void deleteFile(Document document)
	{
		if (null == document || null == document.getId()) return;
		String fileName = document.getId().toString();
		fileManager.deleteFile(document.getFolder(), fileName);
		
		try
		{
			entityManager.remove(document);
			entityManager.flush();
		}
		catch (RuntimeException e)
		{
			log.error(e.getMessage());
		}
	}
	
	public String getAbsolutePath(Document document)
	{
		return fileManager.getAbsolutePath(document.getFolder(), document.getId().toString());
	}

	public Document getDocument(Long id)
	{
		return (Document) entityManager.find(Document.class, id);
	}

	public boolean checkFileExist(Document document) {
		return fileManager.checkFileExist(document.getFolder(), document.getId().toString());
	}

}
