package com.bosch.cdb.session;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.persistence.EntityManager;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.faces.FacesMessages;
import org.jboss.seam.international.StatusMessage.Severity;
import org.jboss.seam.log.Log;

@Name("fileManager")
@Scope(ScopeType.CONVERSATION)
public class FileManager
{
	@Logger Log log;
	@In EntityManager entityManager;
	@In FacesMessages facesMessages;

	@In(value="#{facesContext.externalContext}")
	private ExternalContext extCtx;

	@In(value="#{facesContext}")
	FacesContext facesContext;

	@In(create=true)
	private String fileRoot;
	
	private String getRelativePath(String folder, String fileName)
	{
		StringBuffer relativePath = new StringBuffer();
		if (null != folder && !"".equals(folder.trim()))
		{
			relativePath.append(folder).append("/");
		}
		relativePath.append(fileName);
		return relativePath.toString();
	}
	
	public String getAbsolutePath(String folder, String fileName)
	{
		return fileRoot+getRelativePath(folder, fileName);
	}
	
	public void deleteFile(String folder, String fileName)
	{
		File file = new File(getAbsolutePath(folder, fileName));
		if (!file.exists())
		{
			facesMessages.addFromResourceBundle(Severity.WARN, "fileNotFound", getRelativePath(folder, fileName));
			return;
		}
		File directory = file.getParentFile();
		boolean result = file.delete();
		if (!result)
		{
			facesMessages.addFromResourceBundle(Severity.WARN, "fileCouldNotBeDeleted", getRelativePath(folder, fileName));
			log.warn("File could not be deleted. Path: " + file.getAbsolutePath());
		}
		else
		{
			if(directory.isDirectory() && directory.list().length == 0)
			{
				directory.delete();
			}
		}
	}
	
	public void saveFile(String folder, String fileName, byte[] data) throws IOException
	{
		if (null != data && data.length > 0)
		{
			
			File file = new File(getAbsolutePath(folder, fileName));
			if (null != folder && !"".equals(folder.trim()))
			{
				File parentFolder = new File(fileRoot+"/"+folder);
				if (!parentFolder.exists())
				{
					parentFolder.mkdirs();
				}
			}
			FileOutputStream fos = new FileOutputStream(file);
			fos.write(data);
			fos.close();
		}		
	}

	public void downloadFile(String folder, String fileName, String contentType, String displayFileName ) throws FileNotFoundException, IOException 
	{
		long start = System.currentTimeMillis();
		
		File file = new File(getAbsolutePath(folder, fileName));
		
		if (!file.exists())
		{
			facesMessages.addFromResourceBundle(Severity.WARN, "fileNotFound", getRelativePath(folder, fileName));
			return;
		}
		HttpServletResponse response = (HttpServletResponse)extCtx.getResponse();
		response.setContentType(contentType);
        response.addHeader("Content-disposition", "attachment; filename=\"" + displayFileName +"\"");
		ServletOutputStream os = response.getOutputStream();

		// write content of file into servlet output stream
		FileInputStream fis = new FileInputStream(file);
		char current;
	      while (fis.available() > 0) {
	        current = (char) fis.read();
	        os.write(current);
	      }
		fis.close();

		os.flush();
		os.close();
		
		facesContext.responseComplete();
		
		long end = System.currentTimeMillis();
		long minutes = TimeUnit.MILLISECONDS.toMinutes(end - start);
		log.info(">>>>>>>>>>> Minutes: " + minutes);
	}
	
	public boolean checkFileExist(String folder, String fileName) {
		File file = new File(getAbsolutePath(folder, fileName));
		if (file.exists())
			return true;
		return false;
	}
}
