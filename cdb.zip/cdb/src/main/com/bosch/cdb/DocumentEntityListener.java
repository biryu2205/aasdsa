package com.bosch.cdb;

import java.io.IOException;

import javax.persistence.PostPersist;
import javax.persistence.PostRemove;
import org.jboss.seam.Component;

import com.bosch.cdb.entity.Document;
import com.bosch.cdb.session.DocumentManager;

public class DocumentEntityListener
{
	@PostPersist
	public void postPersist(Object o)
	{
		if (o instanceof Document)
		{
			Document document = (Document) o;
			DocumentManager documentManager = (DocumentManager) Component.getInstance("documentManager");
			try
			{
				documentManager.saveFile(document);
			} catch (IOException e)
			{
				e.printStackTrace();
			}
		}
	}
	
	@PostRemove
	public void postRemove(Object o)
	{
		if (o instanceof Document)
		{
			Document document = (Document) o;
			DocumentManager documentManager = (DocumentManager) Component.getInstance("documentManager");
			documentManager.deleteFile(document);
		}
	}
}
