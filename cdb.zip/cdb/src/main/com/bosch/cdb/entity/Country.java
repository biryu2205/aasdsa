package com.bosch.cdb.entity;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.validator.Length;
import org.hibernate.validator.NotNull;

@Entity
@Table(name="cdb_country")
public class Country implements Comparable<Country>
{
	@Transient
	private boolean editMode = false;

	@Id
	@SequenceGenerator(name = "countrySeqGen", allocationSize = 1, sequenceName = "cdb_s_country")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "countrySeqGen" )
	private Long id;
	
	@Length(max=30)
	@NotNull
	private String name;
	
	@ManyToOne
	@JoinColumn(name="continent_id")
	@NotNull
	private Continent continent;
	
	@Length(min=2,max=2)
	private String code; // alpha-2 code
	
	public Long getId()
	{
		return id;
	}
	public void setId(Long id)
	{
		this.id = id;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public Continent getContinent()
	{
		return continent;
	}
	public void setContinent(Continent continent)
	{
		this.continent = continent;
	}
	public String getCode()
	{
		return code;
	}
	//SETTING CODE
	public void setCode(String code)
	{
		this.code = code;
	}
	
	@Transient
	public static String getCountryListString(List<Country> countryList)
	{
		if (null == countryList || countryList.isEmpty()) return "";
		
		StringBuffer countryListStringBuffer = new StringBuffer();
		Collections.sort(countryList);
		if (null != countryList && !countryList.isEmpty())
		{
			boolean first = true;
			for (Iterator<Country> iterator = countryList.iterator(); iterator.hasNext();)
			{
				if (!first)
				{
					countryListStringBuffer.append(", ");
				}
				else
				{
					first = false;
				}

				Country country = iterator.next();
				countryListStringBuffer.append(country.getCode());
			}
		}
		return countryListStringBuffer.toString();
	}
	public boolean isEditMode()
	{
		return editMode;
	}
	public void setEditMode(boolean editMode)
	{
		this.editMode = editMode;
	}
	public int compareTo(Country o) 
	{
		if (null == code || null == o || null == o.code) return 0;
		return code.compareTo(o.code);
	}

}
