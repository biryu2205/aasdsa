package com.bosch.cdb.entity;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Cascade;
import org.hibernate.validator.Length;
import org.hibernate.validator.NotNull;

@Entity
@Table(name="cdb_product_group")
public class ProductCategory implements Comparable<ProductCategory>
{
	@Transient
	private boolean editMode = false;

	@Transient
	public String getPrefixedId()
	{
		return (null == id)?"":"PG"+id.toString().trim();
	}

	@Id
	@SequenceGenerator(name = "productGroupSeqGen", allocationSize = 1, sequenceName = "cdb_s_product_group")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "productGroupSeqGen" )
	private Long id;
	
	@Length(max=30)
	@NotNull
	private String name;
	
	@ManyToOne
	@JoinColumn(name="product_category_id")
	private ProductType productType;

	@ManyToOne(cascade=CascadeType.ALL)
	@Cascade(org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	@JoinColumn(name="type_plate_doc_id")
	private Document typePlateDoc;	

	@Length(max=2000)
	private String remark;
	
	public Long getId()
	{
		return id;
	}
	public void setId(Long id)
	{
		this.id = id;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public ProductType getProductType()
	{
		return productType;
	}
	public void setProductType(ProductType productType)
	{
		this.productType = productType;
	}
	public String getRemark()
	{
		return remark;
	}
	public void setRemark(String remark)
	{
		this.remark = remark;
	}
	public Document getTypePlateDoc()
	{
		return typePlateDoc;
	}
	public void setTypePlateDoc(Document typePlateDoc)
	{
		this.typePlateDoc = typePlateDoc;
	}
	public boolean isEditMode()
	{
		return editMode;
	}
	public void setEditMode(boolean editMode)
	{
		this.editMode = editMode;
	}

	@Transient
	public static String getProductCategoryString(List<ProductCategory> productCategoryList)
	{
		if (null == productCategoryList || productCategoryList.isEmpty()) return "";
		
		StringBuffer productListStringBuffer = new StringBuffer();
		Collections.sort(productCategoryList);
		if (null != productCategoryList && !productCategoryList.isEmpty())
		{
			boolean first = true;
			for (Iterator<ProductCategory> iterator = productCategoryList.iterator(); iterator.hasNext();)
			{
				if (!first)
				{
					productListStringBuffer.append(", ");
				}
				else
				{
					first = false;
				}

				ProductCategory product = iterator.next();
				productListStringBuffer.append(product.getName());
			}
		}
		return productListStringBuffer.toString();
	}
	public int compareTo(ProductCategory o) 
	{
		if (null == name || null == o || null == o.getName()) return 0;
		return name.compareTo(o.getName());
	}
}
