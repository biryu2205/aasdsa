package com.bosch.cdb.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.validator.Length;
import org.hibernate.validator.NotNull;

import com.bosch.commons.security.User;

@Entity
@Table(name="cdb_product")
public class Product
{
	@Transient
	private boolean editMode = false;

	@Id
	@SequenceGenerator(name = "productSeqGen", allocationSize = 1, sequenceName = "cdb_s_product")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "productSeqGen" )
	private Long id;

	@Column(name="create_date")
	private Date createDate;

	@Column(name="update_date")
	private Date updateDate;

	@ManyToOne
	@JoinColumn(name="create_user_id")
	private User createUser;

	@ManyToOne
	@JoinColumn(name="update_user_id")
	private User updateUser;

	@Length(max=30)
	@NotNull
	private String name;

	@ManyToOne
	@JoinColumn(name="product_group_id")
	@NotNull
	private ProductCategory productCategory;
	
	@ManyToMany
	@JoinTable(name="cdb_brand_product", joinColumns={@JoinColumn(name="product_id")}, inverseJoinColumns={@JoinColumn(name="brand_id")})
	private List<Brand> brandList;

	@Length(max=2000)
	private String remark;
	
	public Long getId()
	{
		return id;
	}
	public void setId(Long id)
	{
		this.id = id;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public String getRemark()
	{
		return remark;
	}
	public void setRemark(String remark)
	{
		this.remark = remark;
	}
	public ProductCategory getProductCategory()
	{
		return productCategory;
	}
	public void setProductCategory(ProductCategory productCategory)
	{
		this.productCategory = productCategory;
	}
	public List<Brand> getBrandList()
	{
		return brandList;
	}
	public void setBrandList(List<Brand> brandList)
	{
		this.brandList = brandList;
	}
	public Date getCreateDate()
	{
		return createDate;
	}
	public void setCreateDate(Date createDate)
	{
		this.createDate = createDate;
	}
	public Date getUpdateDate()
	{
		return updateDate;
	}
	public void setUpdateDate(Date updateDate)
	{
		this.updateDate = updateDate;
	}
	public User getCreateUser()
	{
		return createUser;
	}
	public void setCreateUser(User createUser)
	{
		this.createUser = createUser;
	}
	public User getUpdateUser()
	{
		return updateUser;
	}
	public void setUpdateUser(User updateUser)
	{
		this.updateUser = updateUser;
	}
	public boolean isEditMode()
	{
		return editMode;
	}
	public void setEditMode(boolean editMode)
	{
		this.editMode = editMode;
	}

}
