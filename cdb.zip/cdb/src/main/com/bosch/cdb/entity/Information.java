package com.bosch.cdb.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Cascade;
import org.hibernate.validator.Length;
import org.hibernate.validator.NotNull;

import com.bosch.commons.security.User;

@Entity
@Table(name="cdb_information")
public class Information implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -1050855936035695070L;

	@Transient
	private boolean editMode = false;

	@Transient
	public String getPrefixedId()
	{
		return (null == id)?"":"I"+id.toString().trim();
	}

	@Id
	@SequenceGenerator(name = "informationSeqGen", allocationSize = 1, sequenceName = "cdb_s_information")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "informationSeqGen" )
	private Long id;

	@Column(name="create_date")
	private Date createDate;

	@Column(name="update_date")
	private Date updateDate;

	@ManyToOne
	@JoinColumn(name="create_user_id")
	private User createUser;

	@ManyToOne
	@JoinColumn(name="update_user_id")
	private User updateUser;

	@Length(max=30)
	@NotNull
	private String name;

	@ManyToOne
	@JoinColumn(name="information_type_id")
	@NotNull
	private InformationType informationType;

	@Length(max=10)
	private String abbreviation;

	@Length(max=30)
	private String code;

	@Length(max=2000)
	private String remark;
	
	@ManyToMany
	@JoinTable(name="cdb_country_information", joinColumns={@JoinColumn(name="information_id")}, inverseJoinColumns={@JoinColumn(name="country_id")})
	private List<Country> countryList = new ArrayList<Country>();

	@ManyToMany(cascade=CascadeType.ALL)
	@Cascade(org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	@JoinTable(name="cdb_doc_information_document", joinColumns={@JoinColumn(name="information_id")}, inverseJoinColumns={@JoinColumn(name="document_id")})
	private List<Document> documentList  = new ArrayList<Document>();


	@Transient
	public String getCountryListString()
	{
		return Country.getCountryListString(countryList);
	}
	
	public Long getId()
	{
		return id;
	}
	public void setId(Long id)
	{
		this.id = id;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public InformationType getInformationType()
	{
		return informationType;
	}
	public void setInformationType(InformationType informationType)
	{
		this.informationType = informationType;
	}
	public String getCode()
	{
		return code;
	}
	public void setCode(String code)
	{
		this.code = code;
	}

	public String getAbbreviation()
	{
		return abbreviation;
	}
	public void setAbbreviation(String abbreviation)
	{
		this.abbreviation = abbreviation;
	}
	public List<Country> getCountryList()
	{
		return countryList;
	}
	public void setCountryList(List<Country> countryList)
	{
		this.countryList = countryList;
	}
	public String getRemark()
	{
		return remark;
	}
	public void setRemark(String remark)
	{
		this.remark = remark;
	}

	public Date getCreateDate()
	{
		return createDate;
	}

	public void setCreateDate(Date createDate)
	{
		this.createDate = createDate;
	}

	public Date getUpdateDate()
	{
		return updateDate;
	}

	public void setUpdateDate(Date updateDate)
	{
		this.updateDate = updateDate;
	}

	public User getCreateUser()
	{
		return createUser;
	}

	public void setCreateUser(User createUser)
	{
		this.createUser = createUser;
	}

	public User getUpdateUser()
	{
		return updateUser;
	}

	public void setUpdateUser(User updateUser)
	{
		this.updateUser = updateUser;
	}
	public boolean isEditMode()
	{
		return editMode;
	}

	public void setEditMode(boolean editMode)
	{
		this.editMode = editMode;
	}

	public List<Document> getDocumentList() {
		return documentList;
	}

	public void setDocumentList(List<Document> documentList) {
		this.documentList = documentList;
	}

}
