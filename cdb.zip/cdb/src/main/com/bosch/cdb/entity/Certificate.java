package com.bosch.cdb.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Cascade;
import org.hibernate.validator.Length;
import org.hibernate.validator.NotNull;
import org.hibernate.validator.Size;
import com.bosch.commons.security.User;

@Entity
@Table(name="cdb_certificate")
public class Certificate
{
	@Transient
	private boolean editMode = false;

	@Transient
	public String getPrefixedId()
	{
		return (null == id)?"":"C"+id.toString().trim();
	}

	@Id
	@SequenceGenerator(name = "certificateSeqGen", allocationSize = 1, sequenceName = "cdb_s_certificate")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "certificateSeqGen" )
	private Long id;

	@Column(name="certificate_number")
	@Length(max=30)
	private String certificateNumber;
	
	@Column(name="ttnr_number")
	@Length(max=30)
	private String ttnr;

	@ManyToOne
	@JoinColumn(name="product_id")
	@NotNull
	private Product product;

	@ManyToMany
	@JoinTable(name="cdb_regulation_certificate", joinColumns={@JoinColumn(name="certificate_id")}, inverseJoinColumns={@JoinColumn(name="regulation_id")})
	@Size(min=1)
	private List<Regulation> regulationList;
	
	@ManyToOne
	@JoinColumn(name="institute_id")
	@NotNull
	private Institute institute;

	@Length(max=2000)
	private String remark;
	
	@Column(name="create_date")
	private Date createDate;

	@Column(name="update_date")
	private Date updateDate;

	@ManyToOne
	@JoinColumn(name="create_user_id")
	private User createUser;

	@ManyToOne
	@JoinColumn(name="update_user_id")
	private User updateUser;

	@Column(name="valid_until")
	private Date validUntil;

	@Column(name="expiry_warning")
	private Date expiryWarning;
	
	@Column(name="emailNotification", columnDefinition="boolean default false")
	private Boolean  emailNotification;

	@ManyToMany
	@JoinTable(name="cdb_cert_expwarnrecip", joinColumns={@JoinColumn(name="certificate_id")}, inverseJoinColumns={@JoinColumn(name="user_id")})
	private List<User> expiryWarningRecipientList;

	
	@ManyToMany(cascade=CascadeType.ALL)
	@Cascade(org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	@JoinTable(name="cdb_cert_doc", joinColumns={@JoinColumn(name="certificate_id")}, inverseJoinColumns={@JoinColumn(name="cert_doc_id")})
	private List<Document>  certDocList = new ArrayList<Document>();
	
	@Length(max=2000)
	@Column(name="cert_doc_remark")
	private String certDocRemark;
	
	@ManyToMany(cascade=CascadeType.ALL)
	@Cascade(org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	@JoinTable(name="cdb_cert_eupdirective_doc", joinColumns={@JoinColumn(name="certificate_id")}, inverseJoinColumns={@JoinColumn(name="cert_eupdirective_doc_id")})
	private List<Document> certEupDirectiveDoc = new ArrayList<Document>();
	
	@Length(max=2000)
	@Column(name="cert_eupDirective_doc_remark")
	private String certEupDirectiveDocRemark;
	
	@ManyToMany(cascade=CascadeType.ALL)
	@Cascade(org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	@JoinTable(name="cdb_cert_other_doc", joinColumns={@JoinColumn(name="certificate_id")}, inverseJoinColumns={@JoinColumn(name="cert_other_doc_id")})
	private List<Document> certOtherDoc  = new ArrayList<Document>();;
	
	@Length(max=2000)
	@Column(name="cert_other_doc_remark")
	private String certOtherDocRemark;

	@Length(max=2000)
	@Column(name="conf_decl_doc")
	private String confDeclDoc;
	
	@ManyToMany(cascade=CascadeType.ALL)
	@Cascade(org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	@JoinTable(name="cdb_cert_conf_decl_upl_doc", joinColumns={@JoinColumn(name="certificate_id")}, inverseJoinColumns={@JoinColumn(name="cert_conf_decl_upl_doc_id")})
	private List<Document> confDeclUplDoc = new ArrayList<Document>();;;

	@Length(max=2000)
	@Column(name="conf_decl_doc_remark")
	private String confDeclDocRemark;

	public Long getId()
	{
		return id;
	}
	public void setId(Long id)
	{
		this.id = id;
	}

	public Date getCreateDate()
	{
		return createDate;
	}
	public void setCreateDate(Date createDate)
	{
		this.createDate = createDate;
	}
	public Date getUpdateDate()
	{
		return updateDate;
	}
	public void setUpdateDate(Date updateDate)
	{
		this.updateDate = updateDate;
	}
	public Date getValidUntil()
	{
		return validUntil;
	}
	public void setValidUntil(Date validUntil)
	{
		this.validUntil = validUntil;
	}
	public Institute getInstitute()
	{
		return institute;
	}
	public void setInstitute(Institute institute)
	{
		this.institute = institute;
	}
	public String getRemark()
	{
		return remark;
	}
	public void setRemark(String remark)
	{
		this.remark = remark;
	}
	public List<Document> getCertDocList()
	{
		return certDocList;
	}
	public void setCertDocList(List<Document> list)
	{
		this.certDocList = list;
	}
	public String getCertDocRemark()
	{
		return certDocRemark;
	}
	public void setCertDocRemark(String certDocRemark)
	{
		this.certDocRemark = certDocRemark;
	}
	public List<Document> getCertOtherDocList()
	{
		return certOtherDoc;
	}
	public void setCertOtherDocList(List<Document> list)
	{
		this.certOtherDoc = list;
	}
	public String getCertOtherDocRemark()
	{
		return certOtherDocRemark;
	}
	public void setCertOtherDocRemark(String certOtherDocRemark)
	{
		this.certOtherDocRemark = certOtherDocRemark;
	}
	public String getConfDeclDocRemark()
	{
		return confDeclDocRemark;
	}
	public void setConfDeclDocRemark(String confDeclDocRemark)
	{
		this.confDeclDocRemark = confDeclDocRemark;
	}
	public String getCertificateNumber()
	{
		return certificateNumber;
	}
	public void setCertificateNumber(String certificateNumber)
	{
		this.certificateNumber = certificateNumber;
	}
	public Product getProduct()
	{
		return product;
	}
	public void setProduct(Product product)
	{
		this.product = product;
	}
	public List<Regulation> getRegulationList()
	{
		return regulationList;
	}
	public void setRegulationList(List<Regulation> regulationList)
	{
		this.regulationList = regulationList;
	}
	public User getCreateUser()
	{
		return createUser;
	}
	public void setCreateUser(User createUser)
	{
		this.createUser = createUser;
	}
	public User getUpdateUser()
	{
		return updateUser;
	}
	public void setUpdateUser(User updateUser)
	{
		this.updateUser = updateUser;
	}
	public boolean isEditMode()
	{
		return editMode;
	}
	public void setEditMode(boolean editMode)
	{
		this.editMode = editMode;
	}
	public Date getExpiryWarning()
	{
		return expiryWarning;
	}
	public void setExpiryWarning(Date expiryWarning)
	{
		this.expiryWarning = expiryWarning;
	}
	public List<User> getExpiryWarningRecipientList()
	{
		return expiryWarningRecipientList;
	}
	public void setExpiryWarningRecipientList(List<User> expiryWarningRecipientList)
	{
		this.expiryWarningRecipientList = expiryWarningRecipientList;
	}
	public String getConfDeclDoc() {
		return confDeclDoc;
	}
	public void setConfDeclDoc(String confDeclDoc) {
		this.confDeclDoc = confDeclDoc;
	}
	public List<Document>  getConfDeclUplDocList()
	{
		return confDeclUplDoc;
	}
	public void setConfDeclUplDocList(List<Document>  list)
	{
		this.confDeclUplDoc = list;
	}
	public List<Document> getCertEupDirectiveDocList()
	{
		return certEupDirectiveDoc;
	}
	public void setCertEupDirectiveDocList(List<Document> list)
	{
		this.certEupDirectiveDoc = list;
	}
	public String getCertEupDirectiveDocRemark()
	{
		return certEupDirectiveDocRemark;
	}
	public void setCertEupDirectiveDocRemark(String certEupDirectiveDocRemark)
	{
		this.certEupDirectiveDocRemark = certEupDirectiveDocRemark;
	}
	public void cloneCertificate(Certificate oldCertificate)
	{
		
		this.setCreateDate(oldCertificate.getCreateDate());
		this.setUpdateDate(oldCertificate.getUpdateDate());
		if(oldCertificate.getValidUntil() != null)
		{
			this.setValidUntil((Date)(oldCertificate.getValidUntil().clone()));
		}
		this.setInstitute(oldCertificate.getInstitute());
		this.setRemark(oldCertificate.getRemark());
		
		
		this.setCertificateNumber(oldCertificate.getCertificateNumber());
		this.setProduct(oldCertificate.getProduct());
		
		List<Regulation> newRegulationList  = new ArrayList<Regulation>();;
		for (Regulation oldRegulation : oldCertificate.getRegulationList())
		{
			newRegulationList.add(oldRegulation);
				
		}
		this.setRegulationList(newRegulationList);
				
		this.setCreateUser(oldCertificate.getCreateUser());
		this.setUpdateUser(oldCertificate.getUpdateUser());
		this.setExpiryWarning(oldCertificate.getExpiryWarning());
		
		List<User> newExpiryWarningRecipientList  = new ArrayList<User>();;
		for (User oldUsers : oldCertificate.getExpiryWarningRecipientList())
		{
			newExpiryWarningRecipientList.add(oldUsers);
				
		}
		this.setExpiryWarningRecipientList(newExpiryWarningRecipientList);
	}
		
	
	public void cloneCertificatesDocuments(Certificate oldCertificate)
	{
		List<Document> newCertDocList  = new ArrayList<Document>();;
		for (Document oldDocuments : oldCertificate.getCertDocList())
		{
			if(oldDocuments.getFileSize() > 0 )
			{	
				newCertDocList.add((Document) oldDocuments.cloneDocument(this.getPrefixedId()));
			}	
		}
		this.setCertDocList(newCertDocList);
		this.setCertDocRemark(oldCertificate.certDocRemark);
		
		List<Document> newCertOtherDocList  = new ArrayList<Document>();;
		for (Document oldDocuments : oldCertificate.getCertOtherDocList())
		{
			if(oldDocuments.getFileSize() > 0 )
			{	
				newCertOtherDocList.add((Document) oldDocuments.cloneDocument(this.getPrefixedId()));
			}	
		}
		this.setCertOtherDocList(newCertOtherDocList);
		this.setCertOtherDocRemark(oldCertificate.certOtherDocRemark);
		
		List<Document> newDeclDocList  = new ArrayList<Document>();;
		for (Document oldDocuments : oldCertificate.getConfDeclUplDocList())
		{
			if(oldDocuments.getFileSize() > 0 )
			{	
				newDeclDocList.add((Document) oldDocuments.cloneDocument(this.getPrefixedId()));
			}	
		}		
		this.setConfDeclDoc(oldCertificate.confDeclDoc);
		this.setConfDeclUplDocList(newDeclDocList);
		this.setConfDeclDocRemark(oldCertificate.confDeclDocRemark);
		
		List<Document> newCertEupDirectiveDocList  = new ArrayList<Document>();;
		for (Document oldDocuments : oldCertificate.getCertEupDirectiveDocList())
		{
			if(oldDocuments.getFileSize() > 0 )
			{	
				newCertEupDirectiveDocList.add((Document) oldDocuments.cloneDocument(this.getPrefixedId()));
			}	
		}
		this.setCertEupDirectiveDocList(newCertEupDirectiveDocList);
		this.setCertEupDirectiveDocRemark(oldCertificate.getCertEupDirectiveDocRemark());
	}
	public String getTtnr() {
		return ttnr;
	}
	public void setTtnr(String ttnr) {
		this.ttnr = ttnr;
	}
	public Boolean getEmailNotification() {
		return emailNotification;
	}
	public void setEmailNotification(Boolean emailNotification) {
		this.emailNotification = emailNotification;
	}
	
}
