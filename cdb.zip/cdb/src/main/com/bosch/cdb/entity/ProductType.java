package com.bosch.cdb.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.validator.Length;
import org.hibernate.validator.NotNull;

@Entity
@Table(name="cdb_product_category")
public class ProductType
{
	@Transient
	private boolean editMode = false;

	@Id
	@SequenceGenerator(name = "productCategorySeqGen", allocationSize = 1, sequenceName = "cdb_s_product_category")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "productCategorySeqGen" )
	private Long id;
	
	@Length(max=30)
	@NotNull
	private String name;
	
	@Length(max=2000)
	private String remark;
	
	public Long getId()
	{
		return id;
	}
	public void setId(Long id)
	{
		this.id = id;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public String getRemark()
	{
		return remark;
	}
	public void setRemark(String remark)
	{
		this.remark = remark;
	}
	public boolean isEditMode()
	{
		return editMode;
	}
	public void setEditMode(boolean editMode)
	{
		this.editMode = editMode;
	}

}
