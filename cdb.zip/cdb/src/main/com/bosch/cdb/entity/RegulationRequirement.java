package com.bosch.cdb.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Cascade;
import org.hibernate.validator.Length;
import org.hibernate.validator.NotNull;
import org.hibernate.validator.Size;

import com.bosch.commons.security.User;

@Entity
@Table(name="cdb_reg_req")
public class RegulationRequirement
{
	@Transient
	private boolean editMode = false;

	@Transient
	public String getPrefixedId()
	{
		return (null == id)?"":"RR"+id.toString().trim();
	}

	@Id
	@SequenceGenerator(name = "cerReqSeqGen", allocationSize = 1, sequenceName = "cdb_s_reg_req")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cerReqSeqGen" )
	private Long id;

	@Column(name="create_date")
	private Date createDate;

	@Column(name="update_date")
	private Date updateDate;

	@ManyToOne
	@JoinColumn(name="create_user_id")
	private User createUser;

	@ManyToOne
	@JoinColumn(name="update_user_id")
	private User updateUser;

	@ManyToMany
	@JoinTable(name="cdb_regreq_prodgroup", joinColumns={@JoinColumn(name="regreq_id")}, inverseJoinColumns={@JoinColumn(name="prodgroup_id")})
	@Size(min=1)
	private List<ProductCategory> productCategoryList;

	
	@ManyToOne
	@JoinColumn(name="regulation_id")
	@NotNull
	private Regulation regulation;

	@ManyToMany(cascade=CascadeType.ALL)
	@Cascade(org.hibernate.annotations.CascadeType.DELETE_ORPHAN)
	@JoinTable(name="cdb_doc_regreq_document", joinColumns={@JoinColumn(name="regreq_id")}, inverseJoinColumns={@JoinColumn(name="document_id")})
	private List<Document> documentList  = new ArrayList<Document>();

	
	private Boolean mandatory;

	@Length(max=2000)
	private String remark;
	
	public Long getId()
	{
		return id;
	}
	public void setId(Long id)
	{
		this.id = id;
	}

	public Boolean getMandatory()
	{
		return mandatory;
	}
	public void setMandatory(Boolean mandatory)
	{
		this.mandatory = mandatory;
	}
	public Regulation getRegulation()
	{
		return regulation;
	}
	public void setRegulation(Regulation regulation)
	{
		this.regulation = regulation;
	}

	public List<ProductCategory> getProductCategoryList()
	{
		return productCategoryList;
	}
	
	@Transient
	public String getProductCategoryListString()
	{
		return ProductCategory.getProductCategoryString(productCategoryList);
	}
	
	public void setProductCategoryList(List<ProductCategory> productCategoryList)
	{
		this.productCategoryList = productCategoryList;
	}
	
	public String getRemark()
	{
		return remark;
	}
	public void setRemark(String remark)
	{
		this.remark = remark;
	}
	public Date getCreateDate()
	{
		return createDate;
	}
	public void setCreateDate(Date createDate)
	{
		this.createDate = createDate;
	}
	public Date getUpdateDate()
	{
		return updateDate;
	}
	public void setUpdateDate(Date updateDate)
	{
		this.updateDate = updateDate;
	}
	public User getCreateUser()
	{
		return createUser;
	}
	public void setCreateUser(User createUser)
	{
		this.createUser = createUser;
	}
	public User getUpdateUser()
	{
		return updateUser;
	}
	public void setUpdateUser(User updateUser)
	{
		this.updateUser = updateUser;
	}
	public boolean isEditMode()
	{
		return editMode;
	}
	public void setEditMode(boolean editMode)
	{
		this.editMode = editMode;
	}
	public List<Document> getDocumentList() {
		return documentList;
	}
	public void setDocumentList(List<Document> documentList) {
		this.documentList = documentList;
	}
	
}
