package com.bosch.cdb.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.validator.Length;
import org.hibernate.validator.NotNull;

import com.bosch.commons.security.User;

@Entity
@Table(name="cdb_institute")
public class Institute
{
	@Transient
	private boolean editMode = false;

	@Id
	@SequenceGenerator(name = "instituteSeqGen", allocationSize = 1, sequenceName = "cdb_s_institute")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "instituteSeqGen" )
	private Long id;

	@Column(name="create_date")
	private Date createDate;

	@Column(name="update_date")
	private Date updateDate;

	@ManyToOne
	@JoinColumn(name="create_user_id")
	private User createUser;

	@ManyToOne
	@JoinColumn(name="update_user_id")
	private User updateUser;

	@Length(max=30)
	@NotNull
	private String name;

	@Column(name="contact_person")
	@Length(max=2000)
	private String contactPerson;

	@Length(max=2000)
	private String contact;

	@Length(max=2000)
	private String remark;

	@ManyToMany
	@JoinTable(name="cdb_regulation_institute", joinColumns={@JoinColumn(name="institute_id")}, inverseJoinColumns={@JoinColumn(name="regulation_id")})
	private List<Regulation> regulationList;
	
	@ManyToMany
	@JoinTable(name="cdb_country_institute", joinColumns={@JoinColumn(name="institute_id")}, inverseJoinColumns={@JoinColumn(name="country_id")})
	private List<Country> countryList;
	
	public Long getId()
	{
		return id;
	}
	public void setId(Long id)
	{
		this.id = id;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public String getContact()
	{
		return contact;
	}
	public void setContact(String contact)
	{
		this.contact = contact;
	}
	public String getRemark()
	{
		return remark;
	}
	public void setRemark(String remark)
	{
		this.remark = remark;
	}
	public List<Regulation> getRegulationList()
	{
		return regulationList;
	}
	public void setRegulationList(List<Regulation> regulationList)
	{
		this.regulationList = regulationList;
	}
	public List<Country> getCountryList()
	{
		return countryList;
	}
	public void setCountryList(List<Country> countryList)
	{
		this.countryList = countryList;
	}
	
	public String getContactPerson()
	{
		return contactPerson;
	}
	public void setContactPerson(String contactPerson)
	{
		this.contactPerson = contactPerson;
	}
	@Transient
	public String getCountryListString()
	{
		return Country.getCountryListString(countryList);
	}
	public Date getCreateDate()
	{
		return createDate;
	}
	public void setCreateDate(Date createDate)
	{
		this.createDate = createDate;
	}
	public Date getUpdateDate()
	{
		return updateDate;
	}
	public void setUpdateDate(Date updateDate)
	{
		this.updateDate = updateDate;
	}
	public User getCreateUser()
	{
		return createUser;
	}
	public void setCreateUser(User createUser)
	{
		this.createUser = createUser;
	}
	public User getUpdateUser()
	{
		return updateUser;
	}
	public void setUpdateUser(User updateUser)
	{
		this.updateUser = updateUser;
	}
	public boolean isEditMode()
	{
		return editMode;
	}
	public void setEditMode(boolean editMode)
	{
		this.editMode = editMode;
	}
	

}
