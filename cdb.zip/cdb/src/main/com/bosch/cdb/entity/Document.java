package com.bosch.cdb.entity;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.jboss.seam.annotations.In;

import sun.util.calendar.BaseCalendar;

import com.bosch.cdb.DocumentEntityListener;
import com.bosch.cdb.UploadFile;
import com.bosch.cdb.session.DocumentManager;
import com.bosch.cdb.session.FileManager;

@Entity
@EntityListeners(DocumentEntityListener.class)
@Table(name="cdb_document")
public class Document implements Cloneable
{
	public Document()
	{
		
	}
	
	public Document(String folder, UploadFile uploadFile)
	{
		fileName = uploadFile.getFileNameWithoutPath();
		contentType = uploadFile.getContentType();
		fileSize = uploadFile.getFileSize();
		data = uploadFile.getData();
		this.folder = folder;
	}
	
	@Id
	@SequenceGenerator(name = "documentSequenceGenerator", allocationSize = 1, sequenceName = "cdb_s_document")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "documentSequenceGenerator" )
	private Long id;
	
	@Column(name="file_name")
	private String fileName;

	@Column(name="content_type")
	private String contentType;
	
	@Column(name="file_size")
	private int fileSize;
	
	@Column(name="folder")
	private String folder;

	@Transient
	private byte[] data = new byte[0];

	public Long getId()
	{
		return id;
	}
	public void setId(Long id)
	{
		this.id = id;
	}
	public String getFileName()
	{
		return fileName;
	}
	public void setFileName(String fileName)
	{
		this.fileName = fileName;
	}
	public String getContentType()
	{
		return contentType;
	}
	public void setContentType(String contentType)
	{
		this.contentType = contentType;
	}

	public int getFileSize()
	{
		return fileSize;
	}
	public void setFileSize(int fileSize)
	{
		this.fileSize = fileSize;
	}

	public String getFolder()
	{
		return folder;
	}

	public void setFolder(String folder)
	{
		this.folder = folder;
	}

	public byte[] getData()
	{
		return data;
	}

	public void setData(byte[] data)
	{
		this.data = data;
	}
	
	private String getRelativePath(String folder, String fileName)
	{
		StringBuffer relativePath = new StringBuffer();
		if (null != folder && !"".equals(folder.trim()))
		{
			relativePath.append(folder).append("/");
		}
		relativePath.append(fileName);
		return relativePath.toString();
	}
	
	
	
	private String getAbsolutePath(String folder, String fileName)
	{
		String fileRoot = System.getProperty("file.root");
		if (null == fileRoot || "".equals(fileRoot.trim()))
		{
			fileRoot="/bosch/files/cdb/";
		}
        return fileRoot+getRelativePath(folder, fileName);
	}
	
	  /**
     * Return a copy of this object.
	 * @throws IOException 
     */
	private byte[] transformFile(File file,int length) throws IOException
	{
	      ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
	      FileInputStream fileInputStream = new FileInputStream(file);
	      byte[] buffer = new byte[length];
		 
	       for (int len = fileInputStream.read(buffer); len > 0; len = fileInputStream
	                .read(buffer)) {
	            byteArrayOutputStream.write(buffer, 0, len);
	       }
		 
	       fileInputStream.close();
		 
		    //    System.out.println(new String(byteArrayOutputStream.toByteArray(),
		    //            "UTF-8"));
		    
		     return   byteArrayOutputStream.toByteArray(); 

	}
	
    public Object cloneDocument(String prefixedId) {
    	Document d = null;
        try {
       	File file = new File(getAbsolutePath(this.folder, this.getId().toString()));
	    if (file.exists()) 
	    {
	    	UploadFile ulf = new UploadFile();
	    	ulf.setContentType(this.contentType);
	    	ulf.setFileName(this.fileName);
	    	ulf.setFileSize(this.fileSize);
	        ulf.setData(transformFile(file,this.fileSize));
	        d = new Document(prefixedId, ulf);
	    }

        } catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return d;
    }
}
