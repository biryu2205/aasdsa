package com.bosch.cdb.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.validator.Length;
import org.hibernate.validator.NotNull;

@Entity
@Table(name="cdb_continent")
public class Continent
{
	@Transient
	private boolean editMode = false;

	@Id
	private Long id;
	
	@Length(max=30)
	@NotNull
	private String name;
	
	public Long getId()
	{
		return id;
	}
	public void setId(Long id)
	{
		this.id = id;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public boolean isEditMode()
	{
		return editMode;
	}
	public void setEditMode(boolean editMode)
	{
		this.editMode = editMode;
	}
	
}
