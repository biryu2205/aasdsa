package com.bosch.commons.security;

import java.util.List;

import javax.persistence.EntityManager;

import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.log.Log;
import org.jboss.seam.security.Credentials;

/**
 * Add roles to identity of authenticated user.
 * 
 */
@Name("authenticator")
public class Authenticator
{
    @Logger Log log;
    @In EntityManager entityManager;
    @In CustomIdentity identity;
    @In Credentials credentials;

    /**
     * Add roles to identity of authenticated user.
     *  
     * @return true if user is authenticated, false otherwise
     */
    @SuppressWarnings("unchecked")
    public boolean authenticate()
    {
       	if (null != identity.getUser())
    	{
    		// user already is authenticated
    		return true;
    	}
        String username = credentials.getUsername();

        // user name is mandatory
        if (null == username || "".equals(username.trim()))
        {
            log.warn("Login failed. No user name was specified.");
            return false;
        }

        // Load user from DB and set roles.
        List<User> resultList = (List<User>) entityManager.createQuery(
            "select u from User u where lower(u.userName)=:userName").setParameter("userName", username.toLowerCase()).getResultList();

        if (resultList.size() > 1)
        {
            log.warn("Login failed. User '{0}' not unique in DB.", username);
            return true;
        }
        
        if (resultList.size() == 1)
        {
            User user = (User) resultList.get(0);
            
//            // inactive user gets no roles
//            if (!user.isActive())
//            {
//                log.warn("User '{0}' is not active.", username);
//                return true;
//            }
//
//            // expired user gets no roles
//            Date dateOfExpiry = user.getDateOfExpiry();
//            if (null != dateOfExpiry && dateOfExpiry.before(new Date()))
//            {
//                log.warn("User '{0}' is expired.", username);
//                return true;
//            }

            
        	// add roles to user if he was found in DB
            identity.setUser(user);

            // add roles to identity
            for (Role role : user.getRoleList())
			{
            	String roleName = role.getName();
                identity.addRole(roleName);

                // add transitive roles
                if (roleName.equals("Administrator"))
                {
                	identity.addRole("Writer");
                }
			}
            
            
            return true;
        }
        
        return true;
    }
}
