package com.bosch.commons.security;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.validator.Length;
import org.hibernate.validator.NotNull;

/**
 * The user holds data about the authenticated user.
 * 
 * @author ago8fe
 */
@Entity
@Table(name = "cdb_user")
public class User implements Serializable
{
    private static final long serialVersionUID = 2133588647848749824L;

    @Id
    @SequenceGenerator(name = "userSequenceGenerator", allocationSize = 1, sequenceName = "cdb_s_user")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "userSequenceGenerator")
    private Long id;

    @NotNull
    @Column(name = "user_name", nullable=false, length=255)
    @Length(max=255)
    private String userName;

    @Column(name = "last_name", length=255)
    @Length(max=255)
    private String lastName;

    @Column(name = "first_name", length=255)
    @Length(max=255)
    private String firstName;

    @Column(name = "department", length=255)
    @Length(max=255)
    private String department;
    
    @Column(name = "mail", length=255)
    @Length(max=255)
    private String mail;

    @ManyToMany(cascade = {CascadeType.MERGE, CascadeType.PERSIST})
    @JoinTable(name = "cdb_user_role", joinColumns = {@JoinColumn(name = "user_id")}, inverseJoinColumns = {@JoinColumn(name = "role_id")})
    // Hint: the @JoinTable annotation must be defined in the User object if you want to persist the
    // User object. If it is defined in the Role object, the data is not persisted!
    private List<Role> roleList;

    
    
    /**
     * constructor.
     */
    public User()
	{
		super();
	}

    
    /**
     * Constructor.
     * @param userName
     * @param lastName
     * @param firstName
     * @param mail
     * @param department
     */
	public User(String userName, String lastName, String firstName, String department,String mail)
	{
		super();
		this.userName = userName;
		this.lastName = lastName;
		this.firstName = firstName;
		this.department = department;
		this.mail = mail;
	}

	/**
	 * String representation of the user. 
	 */
	@Override
	public String toString()
	{
		StringBuffer sb = new StringBuffer();
		if (null != lastName && !"".equals(lastName.trim()))
		{
			sb.append(lastName);
		}
		if (null != firstName && !"".equals(firstName.trim()))
		{
			if (sb.length() > 0)
			{
				sb.append(", ");
			}
			sb.append(firstName);
		}
		if (null != department && !"".equals(department.trim()))
		{
			sb.append(" (");
			sb.append(department);
			sb.append(")");
		}
		return sb.toString();

	}



	/**
     * Returns user id.
     * 
     * @return user id
     */
    public Long getId()
    {
        return id;
    }

    /**
     * User id setter.
     * 
     * @param id user id
     */
    public void setId(final Long id)
    {
        this.id = id;
    }

    /**
     * Returns user name.
     * 
     * @return user name
     */
    public String getUserName()
    {
        return userName;
    }

    /**
     * User name setter.
     * 
     * @param userName user name
     */
    public void setUserName(final String userName)
    {
        this.userName = userName;
    }

    /**
     * Returns user last name.
     * 
     * @return user last name
     */
    public String getLastName()
    {
        return lastName;
    }

    /**
     * User last name setter.
     * 
     * @param lastName user last name
     */
    public void setLastName(final String lastName)
    {
        this.lastName = lastName;
    }

    /**
     * Returns user first name.
     * 
     * @return user first name
     */
    public String getFirstName()
    {
        return firstName;
    }

    /**
     * User first name setter.
     * 
     * @param firstName user first name
     */
    public void setFirstName(final String firstName)
    {
        this.firstName = firstName;
    }

    /**
     * Returns list of roles assigned to user.
     * 
     * @return list of roles assigned to user
     */
    public List<Role> getRoleList()
    {
        return roleList;
    }

    /**
     * List of roles assigned to user setter.
     * 
     * @param roleList list of roles assigned to user
     */
    public void setRoleList(final List<Role> roleList)
    {
        this.roleList = roleList;
    }

    /**
     * Returns user department.
     * 
     * @return user department
     */
    public String getDepartment()
    {
        return department;
    }

    /**
     * User department setter.
     * 
     * @param department user department
     */
    public void setDepartment(final String department)
    {
        this.department = department;
    }


	public String getMail() {
		return mail;
	}

	/**
     * User email setter.
     * 
     * @param mail user mail
     */
	public void setMail(String mail) {
		this.mail = mail;
	}
}
