package com.bosch.commons.security;

import static org.jboss.seam.ScopeType.SESSION;

import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.Startup;
import org.jboss.seam.security.Identity;

/**
 * The identity holds information about the authenticated user.
 * 
 * @author grr8wz
 * @author ago8fe
 */
@Name("org.jboss.seam.security.identity")
@Scope(SESSION)
@Startup
public class CustomIdentity extends Identity
{
    private static final long serialVersionUID = -2491160826136034680L;

    private boolean wamAuthenticated = false; // Was this identity authenticated using WAM?

    private User user = null;

    /**
     * Reset all privileges of this identity.
     */
    public void resetPrivileges()
    {
        super.unAuthenticate();
        super.create();
        setUser(null);
        setUsername(null);
        setPassword(null);
        setWamAuthenticated(false);

    }

    /**
     * Returns authenticated user entity.
     * 
     * @return authenticated user entity
     */
    public User getUser()
    {
        return user;
    }

    /**
     * Authenticated user entity setter.
     * 
     * @param user authenticated user entity
     */
    public void setUser(final User user)
    {
        this.user = user;
    }

    /**
     * Returns true if user was authenticated trough WAM.
     * 
     * @return true if user was authenticated trough WAM, false otherwise
     */
    public boolean isWamAuthenticated()
    {
        return wamAuthenticated;
    }

    /**
     * Set true if user was authenticated trough WAM, false otherwise. Use in WAM authentication
     * filter.
     * 
     * @param wamAuthenticated true if user was authenticated trough WAM, false otherwise
     */
    public void setWamAuthenticated(final boolean wamAuthenticated)
    {
        this.wamAuthenticated = wamAuthenticated;
    }

}
