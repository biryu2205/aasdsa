package com.bosch.commons.security;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.validator.Length;


/**
 * A role is used for authorization purposes.
 * 
 * @author ago8fe
 */
@Entity
@Table(name = "cdb_role")
public class Role
{
    @Id
    @SequenceGenerator(name = "roleSequenceGenerator", allocationSize = 1, sequenceName = "sample_s_role")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "roleSequenceGenerator")
    private Long id;

    @Column(name = "name", length=255)
    @Length(max=255)
    private String name;

    @ManyToMany(mappedBy = "roleList", cascade={CascadeType.MERGE, CascadeType.PERSIST})
    private List<User> userList;

    /**
     * Returns role id. 
     * @return role id
     */
    public Long getId()
    {
        return id;
    }

    /**
     * Role id setter.
     * @param id role id
     */
    public void setId(final Long id)
    {
        this.id = id;
    }

    /**
     * Returns role name.
     * @return role name
     */
    public String getName()
    {
        return name;
    }

    /**
     * Role name setter.
     * @param name role name
     */
    public void setName(final String name)
    {
        this.name = name;
    }

    /**
     * Returns list of users with given role assigned.
     * @return list of users with given role assigned
     */
    public List<User> getUserList()
    {
        return userList;
    }

    /**
     * List of users with given role assigned setter.
     * @param userList list of users with given role assigned
     */
    public void setUserList(final List<User> userList)
    {
        this.userList = userList;
    }
}
