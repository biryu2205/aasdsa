package com.bosch.commons.security;

import java.io.IOException;

import javax.security.auth.login.LoginException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.Startup;
import org.jboss.seam.annotations.intercept.BypassInterceptors;
import org.jboss.seam.annotations.web.Filter;
import org.jboss.seam.contexts.Context;
import org.jboss.seam.contexts.SessionContext;
import org.jboss.seam.log.Log;
import org.jboss.seam.security.Credentials;
import org.jboss.seam.security.Identity;
import org.jboss.seam.servlet.ContextualHttpServletRequest;
import org.jboss.seam.servlet.ServletRequestSessionMap;
import org.jboss.seam.web.AbstractFilter;


/**
 * The Filter checks whether the application user has been 
 * authenticated by WAM or not. If so WAM adds a variable 'iv-user' 
 * to the HTTP Header that holds the username as value. The filter basically sets the 
 * attribute 'isWamAuthenticated' of identity component. Privileges are assigned to identity 
 * by Authenticator class later on within the authenticate() method. 
 * 
 * @author grr8wz
 * @author ago8fe
 * @author mwo8fe
 * 
 * @see IvUserAuthenticator
 */
@Filter(within = "org.jboss.seam.web.exceptionFilter")
@Name("ivUserAuthenticationFilter")
@Scope(ScopeType.APPLICATION)
@Startup
@BypassInterceptors
public class IvUserAuthenticationFilter extends AbstractFilter{

	@Logger Log log;

    // Name of variable that contains user name.
    public static final String IV_USER = "iv-user";
	
	
    // Authenticate user using http header variable or query string parameter. 
    public void doFilter(final ServletRequest request, final ServletResponse response, final FilterChain chain) throws IOException, ServletException {

		if (!(request instanceof HttpServletRequest)){
            throw new ServletException("This filter can only process HttpServletRequest requests");
        }//end if

        // retrieve http header variable iv-user
        final HttpServletRequest httpRequest = (HttpServletRequest) request;
        final String ivUser = "weigel"; //httpRequest.getHeader(IV_USER);

        HttpSession session = httpRequest.getSession(); // force session creation
        final Context context = new SessionContext(new ServletRequestSessionMap(httpRequest));
        

        // retrieve identity
        final CustomIdentity identity = (CustomIdentity) context.get(CustomIdentity.class);
        
        if(identity != null){

            Credentials credentials = (Credentials) context.get(Credentials.class);
        	
        	if (ivUser != null && !"".equals(ivUser.trim())){ // user was authenticated by WAM the http header variable was set
        		
        		String username = ivUser.trim();
        		
        		// only if user name has changed
        		if (!username.equals(identity.getCredentials().getUsername())){
        			log.debug("User Changed: from [" + identity.getCredentials().getUsername() + "] to [" + username + "] privileges will be reset");
        			identity.resetPrivileges();
        			identity.setWamAuthenticated(true); 
        			credentials.setUsername(username);
        			credentials.setPassword(username);
        			authenticate(httpRequest, username); 
        			log.debug("User Changed: new user is [" + username + "] privileges have been loaded; The user is" + ((identity.isLoggedIn()) ? " ":" NOT ") + "logged in!");
        		}//end if
        		
        	}else if (identity.isWamAuthenticated()){
        		identity.resetPrivileges();
        	}//end if
        	
        }//end if
        
        chain.doFilter(request, response);
        
    }

    private void authenticate(HttpServletRequest request, final String username) throws ServletException, IOException{
    
    	new ContextualHttpServletRequest(request){
    		@Override
    		public void process() throws ServletException, IOException, LoginException{
    			Identity identity = Identity.instance();
    			identity.getCredentials().setUsername(username);
    			identity.authenticate();
    		}
    	}.run();
    
    }
    


}